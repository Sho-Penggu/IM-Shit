﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory_Management_with_POS_for_Villarmia_Store
{
    public partial class EditProduct : Form
    {
        private const string connectionString = "Data Source=LAPTOP-TV289K79\\SQLEXPRESS;Initial Catalog=villarmiaStore;Integrated Security=True";

        public EditProduct()
        {
            InitializeComponent();
            LoadProductData();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to save the changes?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                // Retrieve user input from textboxes and combobox
                int productID;
                string productName = txtPrdName.Text;
                int price;
                int categoryID;

                if (!int.TryParse(txtPrdID.Text, out productID) || string.IsNullOrWhiteSpace(productName) ||
                    !int.TryParse(txtPrc.Text, out price) || ComboCatg.SelectedItem == null)
                {
                    MessageBox.Show("Please ensure all fields are filled correctly.");
                    return;
                }

                switch (ComboCatg.SelectedItem.ToString())
                {
                    case "KITCHEN":
                        categoryID = 100;
                        break;
                    case "BATHROOM":
                        categoryID = 101;
                        break;
                    case "PLASTICWARES":
                        categoryID = 102;
                        break;
                    case "LAUNDRY":
                        categoryID = 103;
                        break;
                    case "MISCELLANEOUS":
                        categoryID = 104;
                        break;
                    default:
                        categoryID = 105;
                        break;
                }

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("UpdateProduct", connection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.Add("@ProductID", SqlDbType.Int).Value = productID;
                        cmd.Parameters.Add("@ProductName", SqlDbType.NVarChar, 255).Value = productName;
                        cmd.Parameters.Add("@Price", SqlDbType.Int).Value = price;
                        cmd.Parameters.Add("@CategoryID", SqlDbType.Int).Value = categoryID;

                        try
                        {
                            connection.Open();
                            cmd.ExecuteNonQuery();
                            MessageBox.Show("Product updated successfully!");
                            Inventory inv = new Inventory();
                            inv.Show();
                            this.Hide();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("An error occurred: " + ex.Message);
                        }
                    }
                }
            }
        }


        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to Cancel?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                Inventory inv = new Inventory();
                inv.Show();
                this.Hide();
            }
        }

        private void LoadProductData()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM [dbo].[GetProductData]()", connection))
                {
                    cmd.CommandType = CommandType.Text;

                    try
                    {
                        connection.Open();
                        SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);
                        dtaGridProduct.DataSource = dataTable;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An error occurred: " + ex.Message);
                    }
                }
            }
        }
    }
}
