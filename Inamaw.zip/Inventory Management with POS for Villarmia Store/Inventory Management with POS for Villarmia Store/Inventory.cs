﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory_Management_with_POS_for_Villarmia_Store
{
    public partial class Inventory : Form
    {
        private const string connectionString = "Data Source=LAPTOP-TV289K79\\SQLEXPRESS;Initial Catalog=villarmiaStore;Integrated Security=True";

        public Inventory()
        {
            InitializeComponent();
            LoadProductData();
            LoadInventoryData();
        }

        private void eXITToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pOSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            POS pos = new POS();
            pos.Show();
            this.Hide();
        }

        private void sUPPLIESToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Supplies sup = new Supplies();
            sup.Show();
            this.Hide();
        }

        private void srchInventory_MouseClick(object sender, MouseEventArgs e)
        {
            srchInventory.Clear();
        }

        private void srchInventory_MouseLeave(object sender, EventArgs e)
        {
            if (srchInventory.Text == "")
            {
                srchInventory.Text = "SEARCH";
            }
        }

        private void btnADDPrd_Click(object sender, EventArgs e)
        {
            //Pop-up Confirm 1st
            Inventory inv = new Inventory();
            try
            {
                using (ADDinventory ad = new ADDinventory())
                {
                    inv.StartPosition = FormStartPosition.Manual;
                    inv.FormBorderStyle = FormBorderStyle.None;
                    inv.Opacity = 77.77;
                    inv.BackColor = Color.Black;
                    inv.WindowState = FormWindowState.Maximized;
                    inv.TopMost = true;
                    inv.Location = this.Location;
                    inv.ShowInTaskbar = false;
                    inv.Show();

                    ad.Owner = inv;
                    ad.ShowDialog();

                    inv.Dispose();
                    this.Hide();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                inv.Dispose();
            }

        }

        private void btnEDIT_Click(object sender, EventArgs e)
        {
            //Pop-up Confirm 1st
            Inventory inv = new Inventory();
            try
            {
                using (EditInventory edti = new EditInventory())
                {
                    inv.StartPosition = FormStartPosition.Manual;
                    inv.FormBorderStyle = FormBorderStyle.None;
                    inv.Opacity = 77.77;
                    inv.BackColor = Color.Black;
                    inv.WindowState = FormWindowState.Maximized;
                    inv.TopMost = true;
                    inv.Location = this.Location;
                    inv.ShowInTaskbar = false;
                    inv.Show();

                    edti.Owner = inv;
                    edti.ShowDialog();

                    inv.Dispose();
                    this.Hide();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                inv.Dispose();
            }
        }

        private void btnDELETE_Click(object sender, EventArgs e)
        {
            //Pop-up Confirm 1st
            Inventory inv = new Inventory();
            try
            {
                using (InventoryDELETE delinv = new InventoryDELETE())
                {
                    inv.StartPosition = FormStartPosition.Manual;
                    inv.FormBorderStyle = FormBorderStyle.None;
                    inv.Opacity = 77.77;
                    inv.BackColor = Color.Black;
                    inv.WindowState = FormWindowState.Maximized;
                    inv.TopMost = true;
                    inv.Location = this.Location;
                    inv.ShowInTaskbar = false;
                    inv.Show();

                    delinv.Owner = inv;
                    delinv.ShowDialog();

                    inv.Dispose();
                    this.Hide();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                inv.Dispose();
            }
        }


        private void btnEditProd_Click(object sender, EventArgs e)
        {
            //Pop-up Confirm 1st
            Inventory inv = new Inventory();
            try
            {
                using (EditProduct edtp = new EditProduct())
                {
                    inv.StartPosition = FormStartPosition.Manual;
                    inv.FormBorderStyle = FormBorderStyle.None;
                    inv.Opacity = 77.77;
                    inv.BackColor = Color.Black;
                    inv.WindowState = FormWindowState.Maximized;
                    inv.TopMost = true;
                    inv.Location = this.Location;
                    inv.ShowInTaskbar = false;
                    inv.Show();

                    edtp.Owner = inv;
                    edtp.ShowDialog();

                    inv.Dispose();
                    this.Hide();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                inv.Dispose();
            }
        }

        private void btnEditInv_Click(object sender, EventArgs e)
        {
            //Pop-up Confirm 1st
            Inventory inv = new Inventory();
            try
            {
                using (EditInventory edti = new EditInventory())
                {
                    inv.StartPosition = FormStartPosition.Manual;
                    inv.FormBorderStyle = FormBorderStyle.None;
                    inv.Opacity = 77.77;
                    inv.BackColor = Color.Black;
                    inv.WindowState = FormWindowState.Maximized;
                    inv.TopMost = true;
                    inv.Location = this.Location;
                    inv.ShowInTaskbar = false;
                    inv.Show();

                    edti.Owner = inv;
                    edti.ShowDialog();

                    inv.Dispose();
                    this.Hide();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                inv.Dispose();
            }
        }


        //QUERY//
        
        private void RefreshData(DataGridView dataGridView, string searchText = "")
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = dataGridView == dtaGridInventory
                        ? "SELECT * FROM GetInventoryData()"
                        : "SELECT * FROM GetProductData()";

                    if (!string.IsNullOrEmpty(searchText))
                    {
                        if (dataGridView == dtaGridInventory)
                        {
                            query += "WHERE product_ID LIKE @SearchText OR product_name LIKE @SearchText OR quantity LIKE @SearchText OR category_ID LIKE @SearchText OR stock_No LIKE @SearchText OR referential_ID LIKE @SearchText OR delivery_Date LIKE @SearchText OR deleted LIKE @SearchText OR supply_ID LIKE @SearchText";
                        }
                        else
                        {
                            query += " WHERE product_ID LIKE @SearchText OR product_name LIKE @SearchText OR price LIKE @SearchText OR category_ID LIKE @SearchText";
                        }
                    }

                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        if (!string.IsNullOrEmpty(searchText))
                        {
                            cmd.Parameters.Add(new SqlParameter("@SearchText", "%" + searchText + "%"));
                        }

                        using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                        {
                            DataTable dataTable = new DataTable();
                            adapter.Fill(dataTable);
                            dataGridView.DataSource = dataTable;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions (e.g., display an error message)
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }
        

        private void LoadInventoryData()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM [dbo].[GetInventoryData]()", connection))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);
                        dtaGridInventory.DataSource = dataTable;
                    }
                }
            }
        }

        private void LoadProductData()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM [dbo].[GetProductData]()", connection))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);
                        dtaGridProduct.DataSource = dataTable;
                    }
                }
            }
        }

        
        private void srchInventory_TextChanged(object sender, EventArgs e)
        {
            //RefreshData(dtaGridInventory, srchInventory.Text);
            //RefreshData(dtaGridProduct, srchInventory.Text);
        }

        private void srchProduct_TextChanged(object sender, EventArgs e)
        {
            //RefreshData(dtaGridInventory, srchInventory.Text);
            //RefreshData(dtaGridProduct, srchInventory.Text);
        }
        

        private void btnREFRESH_Click(object sender, EventArgs e)
        {
            LoadProductData();
            LoadInventoryData();
        }
        
   
    }
}
