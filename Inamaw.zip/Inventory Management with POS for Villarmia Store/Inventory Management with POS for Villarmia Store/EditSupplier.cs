﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory_Management_with_POS_for_Villarmia_Store
{
    public partial class EditSupplier : Form
    {
        private const string connectionString = "Data Source=LAPTOP-TV289K79\\SQLEXPRESS;Initial Catalog=villarmiaStore;Integrated Security=True";

        public EditSupplier()
        {
            InitializeComponent();
            PopulateDataGridView();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            int supplierID = int.Parse(txtSuplyrID.Text);
            string newCompanyName = txtCompaNm.Text;
            string newAddress = txtAddrss.Text;
            int newPhoneNumber = int.Parse(txtPhnNum.Text);

            // Call the UpdateSupplier stored procedure
            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand("UpdateSupplier", connection))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@supplierID", supplierID);
                cmd.Parameters.AddWithValue("@newCompanyName", newCompanyName);
                cmd.Parameters.AddWithValue("@newAddress", newAddress);
                cmd.Parameters.AddWithValue("@newPhoneNumber", newPhoneNumber);

                connection.Open();
                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Supplier information updated successfully.");

            // Refresh the data grid view after updating
            PopulateDataGridView();
        }

        private void PopulateDataGridView()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand("SELECT supplier_ID AS SupplierID, company_name AS CompanyName, comp_address AS Address, phone_number AS PhoneNumber FROM Supplier", connection))
            using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
            {
                DataTable supplierTable = new DataTable();
                adapter.Fill(supplierTable);

                dtaGridSupplier.DataSource = supplierTable;
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to Cancel?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                Supplies sup = new Supplies();
                sup.Show();
                this.Hide();
            }
        }


    }
}
