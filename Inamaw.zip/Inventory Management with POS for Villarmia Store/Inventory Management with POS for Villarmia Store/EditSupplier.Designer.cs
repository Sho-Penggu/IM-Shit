﻿namespace Inventory_Management_with_POS_for_Villarmia_Store
{
    partial class EditSupplier
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EditSupplier));
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblTitle = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.txtPhnNum = new System.Windows.Forms.TextBox();
            this.txtAddrss = new System.Windows.Forms.TextBox();
            this.txtCompaNm = new System.Windows.Forms.TextBox();
            this.txtSuplyrID = new System.Windows.Forms.TextBox();
            this.lblPhnNo = new System.Windows.Forms.Label();
            this.lblAddrss = new System.Windows.Forms.Label();
            this.lblCompNm = new System.Windows.Forms.Label();
            this.lblSupyr = new System.Windows.Forms.Label();
            this.lblSuplrID = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dtaGridSupplier = new System.Windows.Forms.DataGridView();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtaGridSupplier)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.panel1.Controls.Add(this.lblTitle);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(4, 5);
            this.panel1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(970, 566);
            this.panel1.TabIndex = 0;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(375, 11);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(252, 36);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "EDIT SUPPLIER";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Honeydew;
            this.panel2.Controls.Add(this.btnSave);
            this.panel2.Controls.Add(this.btnCancel);
            this.panel2.Controls.Add(this.txtPhnNum);
            this.panel2.Controls.Add(this.txtAddrss);
            this.panel2.Controls.Add(this.txtCompaNm);
            this.panel2.Controls.Add(this.txtSuplyrID);
            this.panel2.Controls.Add(this.lblPhnNo);
            this.panel2.Controls.Add(this.lblAddrss);
            this.panel2.Controls.Add(this.lblCompNm);
            this.panel2.Controls.Add(this.lblSupyr);
            this.panel2.Controls.Add(this.lblSuplrID);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Location = new System.Drawing.Point(14, 64);
            this.panel2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(938, 489);
            this.panel2.TabIndex = 0;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.LightGreen;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(366, 438);
            this.btnSave.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(147, 41);
            this.btnSave.TabIndex = 3;
            this.btnSave.Text = "SAVE";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.IndianRed;
            this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.Location = new System.Drawing.Point(42, 438);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(147, 41);
            this.btnCancel.TabIndex = 3;
            this.btnCancel.Text = "CANCEL";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // txtPhnNum
            // 
            this.txtPhnNum.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtPhnNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPhnNum.Location = new System.Drawing.Point(207, 338);
            this.txtPhnNum.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtPhnNum.Name = "txtPhnNum";
            this.txtPhnNum.Size = new System.Drawing.Size(325, 32);
            this.txtPhnNum.TabIndex = 2;
            // 
            // txtAddrss
            // 
            this.txtAddrss.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtAddrss.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddrss.Location = new System.Drawing.Point(207, 251);
            this.txtAddrss.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtAddrss.Name = "txtAddrss";
            this.txtAddrss.Size = new System.Drawing.Size(325, 32);
            this.txtAddrss.TabIndex = 2;
            // 
            // txtCompaNm
            // 
            this.txtCompaNm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtCompaNm.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCompaNm.Location = new System.Drawing.Point(207, 161);
            this.txtCompaNm.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtCompaNm.Name = "txtCompaNm";
            this.txtCompaNm.Size = new System.Drawing.Size(325, 32);
            this.txtCompaNm.TabIndex = 2;
            // 
            // txtSuplyrID
            // 
            this.txtSuplyrID.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtSuplyrID.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSuplyrID.Location = new System.Drawing.Point(207, 69);
            this.txtSuplyrID.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtSuplyrID.Name = "txtSuplyrID";
            this.txtSuplyrID.Size = new System.Drawing.Size(325, 32);
            this.txtSuplyrID.TabIndex = 2;
            // 
            // lblPhnNo
            // 
            this.lblPhnNo.AutoSize = true;
            this.lblPhnNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhnNo.Location = new System.Drawing.Point(53, 338);
            this.lblPhnNo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblPhnNo.Name = "lblPhnNo";
            this.lblPhnNo.Size = new System.Drawing.Size(138, 26);
            this.lblPhnNo.TabIndex = 1;
            this.lblPhnNo.Text = "Phone No. :";
            // 
            // lblAddrss
            // 
            this.lblAddrss.AutoSize = true;
            this.lblAddrss.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddrss.Location = new System.Drawing.Point(77, 254);
            this.lblAddrss.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAddrss.Name = "lblAddrss";
            this.lblAddrss.Size = new System.Drawing.Size(113, 26);
            this.lblAddrss.TabIndex = 1;
            this.lblAddrss.Text = "Address :";
            // 
            // lblCompNm
            // 
            this.lblCompNm.AutoSize = true;
            this.lblCompNm.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCompNm.Location = new System.Drawing.Point(5, 161);
            this.lblCompNm.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCompNm.Name = "lblCompNm";
            this.lblCompNm.Size = new System.Drawing.Size(197, 26);
            this.lblCompNm.TabIndex = 1;
            this.lblCompNm.Text = "Company Name :";
            // 
            // lblSupyr
            // 
            this.lblSupyr.AutoSize = true;
            this.lblSupyr.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSupyr.Location = new System.Drawing.Point(582, 11);
            this.lblSupyr.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSupyr.Name = "lblSupyr";
            this.lblSupyr.Size = new System.Drawing.Size(130, 26);
            this.lblSupyr.TabIndex = 1;
            this.lblSupyr.Text = "SUPPLIER";
            // 
            // lblSuplrID
            // 
            this.lblSuplrID.AutoSize = true;
            this.lblSuplrID.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSuplrID.Location = new System.Drawing.Point(47, 69);
            this.lblSuplrID.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSuplrID.Name = "lblSuplrID";
            this.lblSuplrID.Size = new System.Drawing.Size(145, 26);
            this.lblSuplrID.TabIndex = 1;
            this.lblSuplrID.Text = "Supplier ID :";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.dtaGridSupplier);
            this.panel3.Location = new System.Drawing.Point(574, 40);
            this.panel3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(350, 440);
            this.panel3.TabIndex = 0;
            // 
            // dtaGridSupplier
            // 
            this.dtaGridSupplier.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtaGridSupplier.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtaGridSupplier.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dtaGridSupplier.Location = new System.Drawing.Point(0, 0);
            this.dtaGridSupplier.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dtaGridSupplier.Name = "dtaGridSupplier";
            this.dtaGridSupplier.RowHeadersVisible = false;
            this.dtaGridSupplier.RowHeadersWidth = 51;
            this.dtaGridSupplier.RowTemplate.Height = 24;
            this.dtaGridSupplier.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtaGridSupplier.Size = new System.Drawing.Size(350, 440);
            this.dtaGridSupplier.TabIndex = 0;
            // 
            // EditSupplier
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.ForestGreen;
            this.ClientSize = new System.Drawing.Size(978, 581);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "EditSupplier";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "EditSupplies";
            this.TopMost = true;
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtaGridSupplier)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblSuplrID;
        private System.Windows.Forms.DataGridView dtaGridSupplier;
        private System.Windows.Forms.Label lblAddrss;
        private System.Windows.Forms.Label lblCompNm;
        private System.Windows.Forms.TextBox txtAddrss;
        private System.Windows.Forms.TextBox txtCompaNm;
        private System.Windows.Forms.TextBox txtSuplyrID;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label lblSupyr;
        private System.Windows.Forms.TextBox txtPhnNum;
        private System.Windows.Forms.Label lblPhnNo;
    }
}