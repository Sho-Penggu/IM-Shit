﻿namespace Inventory_Management_with_POS_for_Villarmia_Store
{
    partial class ADDinventory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ADDinventory));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dtaGridProduct = new System.Windows.Forms.DataGridView();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.cmBoxCategory = new System.Windows.Forms.ComboBox();
            this.txtBoxPrice = new System.Windows.Forms.TextBox();
            this.txtBoxPName = new System.Windows.Forms.TextBox();
            this.lblCategory = new System.Windows.Forms.Label();
            this.lblProduct = new System.Windows.Forms.Label();
            this.lblQnty = new System.Windows.Forms.Label();
            this.lblPrdNm = new System.Windows.Forms.Label();
            this.lblTITLE = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtaGridProduct)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.lblTITLE);
            this.panel1.Location = new System.Drawing.Point(4, 5);
            this.panel1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(968, 570);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackColor = System.Drawing.Color.Honeydew;
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.btnSave);
            this.panel2.Controls.Add(this.btnCancel);
            this.panel2.Controls.Add(this.cmBoxCategory);
            this.panel2.Controls.Add(this.txtBoxPrice);
            this.panel2.Controls.Add(this.txtBoxPName);
            this.panel2.Controls.Add(this.lblCategory);
            this.panel2.Controls.Add(this.lblProduct);
            this.panel2.Controls.Add(this.lblQnty);
            this.panel2.Controls.Add(this.lblPrdNm);
            this.panel2.Location = new System.Drawing.Point(14, 64);
            this.panel2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(938, 489);
            this.panel2.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.dtaGridProduct);
            this.panel3.Location = new System.Drawing.Point(574, 40);
            this.panel3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(350, 440);
            this.panel3.TabIndex = 4;
            // 
            // dtaGridProduct
            // 
            this.dtaGridProduct.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtaGridProduct.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtaGridProduct.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dtaGridProduct.Location = new System.Drawing.Point(0, 0);
            this.dtaGridProduct.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dtaGridProduct.Name = "dtaGridProduct";
            this.dtaGridProduct.RowHeadersVisible = false;
            this.dtaGridProduct.RowHeadersWidth = 51;
            this.dtaGridProduct.RowTemplate.Height = 24;
            this.dtaGridProduct.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtaGridProduct.Size = new System.Drawing.Size(350, 440);
            this.dtaGridProduct.TabIndex = 0;
            // 
            // btnSave
            // 
            this.btnSave.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnSave.BackColor = System.Drawing.Color.LightGreen;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(366, 438);
            this.btnSave.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(147, 41);
            this.btnSave.TabIndex = 3;
            this.btnSave.Text = "SAVE";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnCancel.BackColor = System.Drawing.Color.IndianRed;
            this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.Location = new System.Drawing.Point(42, 438);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(147, 41);
            this.btnCancel.TabIndex = 3;
            this.btnCancel.Text = "CANCEL";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // cmBoxCategory
            // 
            this.cmBoxCategory.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cmBoxCategory.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.cmBoxCategory.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmBoxCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmBoxCategory.FormattingEnabled = true;
            this.cmBoxCategory.Items.AddRange(new object[] {
            "KITCHEN",
            "BATHROOM",
            "PLASTICWARES",
            "LAUNDRY",
            "MISCELLANEOUS",
            "SAMPLE CATEGORY"});
            this.cmBoxCategory.Location = new System.Drawing.Point(190, 297);
            this.cmBoxCategory.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cmBoxCategory.Name = "cmBoxCategory";
            this.cmBoxCategory.Size = new System.Drawing.Size(221, 34);
            this.cmBoxCategory.TabIndex = 2;
            // 
            // txtBoxPrice
            // 
            this.txtBoxPrice.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtBoxPrice.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtBoxPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxPrice.Location = new System.Drawing.Point(189, 178);
            this.txtBoxPrice.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtBoxPrice.Name = "txtBoxPrice";
            this.txtBoxPrice.Size = new System.Drawing.Size(325, 32);
            this.txtBoxPrice.TabIndex = 1;
            // 
            // txtBoxPName
            // 
            this.txtBoxPName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtBoxPName.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtBoxPName.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxPName.Location = new System.Drawing.Point(190, 54);
            this.txtBoxPName.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtBoxPName.Name = "txtBoxPName";
            this.txtBoxPName.Size = new System.Drawing.Size(325, 32);
            this.txtBoxPName.TabIndex = 1;
            // 
            // lblCategory
            // 
            this.lblCategory.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblCategory.AutoSize = true;
            this.lblCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCategory.Location = new System.Drawing.Point(54, 299);
            this.lblCategory.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCategory.Name = "lblCategory";
            this.lblCategory.Size = new System.Drawing.Size(122, 26);
            this.lblCategory.TabIndex = 0;
            this.lblCategory.Text = "Category :";
            // 
            // lblProduct
            // 
            this.lblProduct.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblProduct.AutoSize = true;
            this.lblProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProduct.Location = new System.Drawing.Point(582, 11);
            this.lblProduct.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblProduct.Name = "lblProduct";
            this.lblProduct.Size = new System.Drawing.Size(127, 26);
            this.lblProduct.TabIndex = 0;
            this.lblProduct.Text = "PRODUCT";
            // 
            // lblQnty
            // 
            this.lblQnty.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblQnty.AutoSize = true;
            this.lblQnty.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQnty.Location = new System.Drawing.Point(92, 180);
            this.lblQnty.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblQnty.Name = "lblQnty";
            this.lblQnty.Size = new System.Drawing.Size(81, 26);
            this.lblQnty.TabIndex = 0;
            this.lblQnty.Text = "Price :";
            // 
            // lblPrdNm
            // 
            this.lblPrdNm.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblPrdNm.AutoSize = true;
            this.lblPrdNm.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrdNm.Location = new System.Drawing.Point(3, 54);
            this.lblPrdNm.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblPrdNm.Name = "lblPrdNm";
            this.lblPrdNm.Size = new System.Drawing.Size(178, 26);
            this.lblPrdNm.TabIndex = 0;
            this.lblPrdNm.Text = "Product Name :";
            // 
            // lblTITLE
            // 
            this.lblTITLE.AutoSize = true;
            this.lblTITLE.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTITLE.Location = new System.Drawing.Point(375, 11);
            this.lblTITLE.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTITLE.Name = "lblTITLE";
            this.lblTITLE.Size = new System.Drawing.Size(243, 36);
            this.lblTITLE.TabIndex = 0;
            this.lblTITLE.Text = "ADD PRODUCT";
            // 
            // ADDinventory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.ForestGreen;
            this.ClientSize = new System.Drawing.Size(978, 581);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "ADDinventory";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ADDinventory";
            this.TopMost = true;
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtaGridProduct)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblCategory;
        private System.Windows.Forms.Label lblQnty;
        private System.Windows.Forms.Label lblPrdNm;
        private System.Windows.Forms.Label lblTITLE;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.ComboBox cmBoxCategory;
        private System.Windows.Forms.TextBox txtBoxPrice;
        private System.Windows.Forms.TextBox txtBoxPName;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DataGridView dtaGridProduct;
        private System.Windows.Forms.Label lblProduct;
    }
}