﻿namespace Inventory_Management_with_POS_for_Villarmia_Store
{
    partial class Inventory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Inventory));
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblPRODUCT = new System.Windows.Forms.Label();
            this.lblINVENTORY = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dtaGridProduct = new System.Windows.Forms.DataGridView();
            this.btnDELETE = new System.Windows.Forms.Button();
            this.btnREFRESH = new System.Windows.Forms.Button();
            this.btnEditInv = new System.Windows.Forms.Button();
            this.btnEditProd = new System.Windows.Forms.Button();
            this.btnADDPrd = new System.Windows.Forms.Button();
            this.srchInventory = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dtaGridInventory = new System.Windows.Forms.DataGridView();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.mENUToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eXITToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vIEWSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pOSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sUPPLIESToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtaGridProduct)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtaGridInventory)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.panel1.Controls.Add(this.lblPRODUCT);
            this.panel1.Controls.Add(this.lblINVENTORY);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.btnDELETE);
            this.panel1.Controls.Add(this.btnREFRESH);
            this.panel1.Controls.Add(this.btnEditInv);
            this.panel1.Controls.Add(this.btnEditProd);
            this.panel1.Controls.Add(this.btnADDPrd);
            this.panel1.Controls.Add(this.srchInventory);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(0, 25);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(928, 483);
            this.panel1.TabIndex = 0;
            // 
            // lblPRODUCT
            // 
            this.lblPRODUCT.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblPRODUCT.AutoSize = true;
            this.lblPRODUCT.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPRODUCT.Location = new System.Drawing.Point(622, 70);
            this.lblPRODUCT.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblPRODUCT.Name = "lblPRODUCT";
            this.lblPRODUCT.Size = new System.Drawing.Size(127, 26);
            this.lblPRODUCT.TabIndex = 1;
            this.lblPRODUCT.Text = "PRODUCT";
            // 
            // lblINVENTORY
            // 
            this.lblINVENTORY.AutoSize = true;
            this.lblINVENTORY.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblINVENTORY.Location = new System.Drawing.Point(16, 68);
            this.lblINVENTORY.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblINVENTORY.Name = "lblINVENTORY";
            this.lblINVENTORY.Size = new System.Drawing.Size(150, 26);
            this.lblINVENTORY.TabIndex = 1;
            this.lblINVENTORY.Text = "INVENTORY";
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.Controls.Add(this.dtaGridProduct);
            this.panel3.Location = new System.Drawing.Point(613, 98);
            this.panel3.Margin = new System.Windows.Forms.Padding(2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(305, 370);
            this.panel3.TabIndex = 3;
            // 
            // dtaGridProduct
            // 
            this.dtaGridProduct.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtaGridProduct.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtaGridProduct.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dtaGridProduct.Location = new System.Drawing.Point(0, 0);
            this.dtaGridProduct.Margin = new System.Windows.Forms.Padding(2);
            this.dtaGridProduct.Name = "dtaGridProduct";
            this.dtaGridProduct.RowHeadersVisible = false;
            this.dtaGridProduct.RowHeadersWidth = 51;
            this.dtaGridProduct.RowTemplate.Height = 24;
            this.dtaGridProduct.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtaGridProduct.Size = new System.Drawing.Size(305, 370);
            this.dtaGridProduct.TabIndex = 0;
            // 
            // btnDELETE
            // 
            this.btnDELETE.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDELETE.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDELETE.Location = new System.Drawing.Point(830, 20);
            this.btnDELETE.Margin = new System.Windows.Forms.Padding(2);
            this.btnDELETE.Name = "btnDELETE";
            this.btnDELETE.Size = new System.Drawing.Size(88, 33);
            this.btnDELETE.TabIndex = 2;
            this.btnDELETE.Text = "DELETE";
            this.btnDELETE.UseVisualStyleBackColor = true;
            this.btnDELETE.Click += new System.EventHandler(this.btnDELETE_Click);
            // 
            // btnREFRESH
            // 
            this.btnREFRESH.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnREFRESH.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnREFRESH.Location = new System.Drawing.Point(721, 20);
            this.btnREFRESH.Margin = new System.Windows.Forms.Padding(2);
            this.btnREFRESH.Name = "btnREFRESH";
            this.btnREFRESH.Size = new System.Drawing.Size(88, 33);
            this.btnREFRESH.TabIndex = 2;
            this.btnREFRESH.Text = "REFRESH";
            this.btnREFRESH.UseVisualStyleBackColor = true;
            this.btnREFRESH.Click += new System.EventHandler(this.btnREFRESH_Click);
            // 
            // btnEditInv
            // 
            this.btnEditInv.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnEditInv.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditInv.Location = new System.Drawing.Point(381, 20);
            this.btnEditInv.Margin = new System.Windows.Forms.Padding(2);
            this.btnEditInv.Name = "btnEditInv";
            this.btnEditInv.Size = new System.Drawing.Size(152, 33);
            this.btnEditInv.TabIndex = 2;
            this.btnEditInv.Text = "EDIT INVENTORY";
            this.btnEditInv.UseVisualStyleBackColor = true;
            this.btnEditInv.Click += new System.EventHandler(this.btnEditInv_Click);
            // 
            // btnEditProd
            // 
            this.btnEditProd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnEditProd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditProd.Location = new System.Drawing.Point(554, 20);
            this.btnEditProd.Margin = new System.Windows.Forms.Padding(2);
            this.btnEditProd.Name = "btnEditProd";
            this.btnEditProd.Size = new System.Drawing.Size(146, 33);
            this.btnEditProd.TabIndex = 2;
            this.btnEditProd.Text = "EDIT PRODUCT";
            this.btnEditProd.UseVisualStyleBackColor = true;
            this.btnEditProd.Click += new System.EventHandler(this.btnEditProd_Click);
            // 
            // btnADDPrd
            // 
            this.btnADDPrd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnADDPrd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnADDPrd.Location = new System.Drawing.Point(200, 20);
            this.btnADDPrd.Margin = new System.Windows.Forms.Padding(2);
            this.btnADDPrd.Name = "btnADDPrd";
            this.btnADDPrd.Size = new System.Drawing.Size(156, 33);
            this.btnADDPrd.TabIndex = 2;
            this.btnADDPrd.Text = "ADD PRODUCT";
            this.btnADDPrd.UseVisualStyleBackColor = true;
            this.btnADDPrd.Click += new System.EventHandler(this.btnADDPrd_Click);
            // 
            // srchInventory
            // 
            this.srchInventory.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.srchInventory.Location = new System.Drawing.Point(21, 25);
            this.srchInventory.Margin = new System.Windows.Forms.Padding(2);
            this.srchInventory.Name = "srchInventory";
            this.srchInventory.Size = new System.Drawing.Size(374, 28);
            this.srchInventory.TabIndex = 1;
            this.srchInventory.Text = "SEARCH";
            this.srchInventory.MouseClick += new System.Windows.Forms.MouseEventHandler(this.srchInventory_MouseClick);
            this.srchInventory.TextChanged += new System.EventHandler(this.srchInventory_TextChanged);
            this.srchInventory.MouseLeave += new System.EventHandler(this.srchInventory_MouseLeave);
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.Controls.Add(this.dtaGridInventory);
            this.panel2.Location = new System.Drawing.Point(9, 97);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(599, 372);
            this.panel2.TabIndex = 0;
            // 
            // dtaGridInventory
            // 
            this.dtaGridInventory.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtaGridInventory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtaGridInventory.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dtaGridInventory.Location = new System.Drawing.Point(0, 0);
            this.dtaGridInventory.Margin = new System.Windows.Forms.Padding(2);
            this.dtaGridInventory.Name = "dtaGridInventory";
            this.dtaGridInventory.RowHeadersVisible = false;
            this.dtaGridInventory.RowHeadersWidth = 51;
            this.dtaGridInventory.RowTemplate.Height = 24;
            this.dtaGridInventory.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtaGridInventory.Size = new System.Drawing.Size(599, 372);
            this.dtaGridInventory.TabIndex = 0;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Aquamarine;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mENUToolStripMenuItem,
            this.vIEWSToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(928, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // mENUToolStripMenuItem
            // 
            this.mENUToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.eXITToolStripMenuItem});
            this.mENUToolStripMenuItem.Name = "mENUToolStripMenuItem";
            this.mENUToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.mENUToolStripMenuItem.Text = "MENU";
            // 
            // eXITToolStripMenuItem
            // 
            this.eXITToolStripMenuItem.Name = "eXITToolStripMenuItem";
            this.eXITToolStripMenuItem.Size = new System.Drawing.Size(96, 22);
            this.eXITToolStripMenuItem.Text = "EXIT";
            this.eXITToolStripMenuItem.Click += new System.EventHandler(this.eXITToolStripMenuItem_Click);
            // 
            // vIEWSToolStripMenuItem
            // 
            this.vIEWSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pOSToolStripMenuItem,
            this.sUPPLIESToolStripMenuItem});
            this.vIEWSToolStripMenuItem.Name = "vIEWSToolStripMenuItem";
            this.vIEWSToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.vIEWSToolStripMenuItem.Text = "GO TO";
            // 
            // pOSToolStripMenuItem
            // 
            this.pOSToolStripMenuItem.Name = "pOSToolStripMenuItem";
            this.pOSToolStripMenuItem.Size = new System.Drawing.Size(123, 22);
            this.pOSToolStripMenuItem.Text = "POS";
            this.pOSToolStripMenuItem.Click += new System.EventHandler(this.pOSToolStripMenuItem_Click);
            // 
            // sUPPLIESToolStripMenuItem
            // 
            this.sUPPLIESToolStripMenuItem.Name = "sUPPLIESToolStripMenuItem";
            this.sUPPLIESToolStripMenuItem.Size = new System.Drawing.Size(123, 22);
            this.sUPPLIESToolStripMenuItem.Text = "SUPPLIES";
            this.sUPPLIESToolStripMenuItem.Click += new System.EventHandler(this.sUPPLIESToolStripMenuItem_Click);
            // 
            // Inventory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.ForestGreen;
            this.ClientSize = new System.Drawing.Size(928, 518);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Inventory";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Inventory";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtaGridProduct)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtaGridInventory)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mENUToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eXITToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vIEWSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pOSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sUPPLIESToolStripMenuItem;
        private System.Windows.Forms.Button btnDELETE;
        private System.Windows.Forms.Button btnREFRESH;
        private System.Windows.Forms.Button btnEditProd;
        private System.Windows.Forms.Button btnADDPrd;
        private System.Windows.Forms.TextBox srchInventory;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView dtaGridInventory;
        private System.Windows.Forms.Label lblPRODUCT;
        private System.Windows.Forms.Label lblINVENTORY;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DataGridView dtaGridProduct;
        private System.Windows.Forms.Button btnEditInv;
    }
}