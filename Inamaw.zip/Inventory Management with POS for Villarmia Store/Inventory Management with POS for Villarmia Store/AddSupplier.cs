﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory_Management_with_POS_for_Villarmia_Store
{
    public partial class AddSupplier : Form
    {

        private const string connectionString = "Data Source=LAPTOP-TV289K79\\SQLEXPRESS;Initial Catalog=villarmiaStore;Integrated Security=True";

        public AddSupplier()
        {
            InitializeComponent();
            LoadSupplierData();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are there no mistakes typed in the inputs?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Create a SqlCommand to execute the stored procedure
                    using (SqlCommand cmd = new SqlCommand("InsertSupplier", connection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        // Add parameters to the stored procedure
                        cmd.Parameters.AddWithValue("@CompanyName", textBox1.Text);
                        cmd.Parameters.AddWithValue("@Address", textBox2.Text);
                        cmd.Parameters.AddWithValue("@PhoneNumber", int.Parse(textBox3.Text)); // Assuming PhoneNumber is an integer

                        // Execute the stored procedure
                        cmd.ExecuteNonQuery();
                    }

                }
                Supplies supp = new Supplies();
                supp.Show();
                this.Hide();

                // You can also refresh your supplier list or perform any other actions here
            }
        }


        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to Cancel?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                Supplies supp = new Supplies();
                supp.Show();
                this.Hide();
            }
        }

        private void LoadSupplierData()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM [dbo].[GetSupplierData]()", connection))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);
                        dtaGridSupplier.DataSource = dataTable;
                    }
                }
            }
        }
    }
}
