﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory_Management_with_POS_for_Villarmia_Store
{
    public partial class POS : Form
    {
        private const string connectionString = "Data Source=LAPTOP-TV289K79\\SQLEXPRESS;Initial Catalog=villarmiaStore;Integrated Security=True";
        public POS()
        {
            InitializeComponent();
        }

        private void eXITToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
           POS pos = new POS();
            pos.Show();
            this.Hide();
        }

        private void iNVENTORYToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Inventory inv = new Inventory();
            inv.Show();
            this.Hide();
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            //Pop-up Remove 1st
            if (MessageBox.Show("Are you sure you want to remove the said item?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                if (MessageBox.Show("THE SAID ITEM WILL BE REMOVED TO THE LIST OF PURCHASE!", "WARNING MESSAGE!!!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    POS pOS = new POS();
                    pOS.Show();
                    this.Hide();
                }
            }
        }

        private void sUPPLIESToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Supplies sup = new Supplies();
            sup.Show();
            this.Hide();
        }

        private void srch_MouseClick(object sender, MouseEventArgs e)
        {
            srchPrd.Clear();
        }

        private void srch_MouseLeave(object sender, EventArgs e)
        {            
            if (srchPrd.Text == "")
              {
                srchPrd.Text = "SEARCH";
              }            
        }

        private void txtprice_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtprice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Return))
            {
                MessageBox.Show("AMOUNT ENTERED!");
            }
        }

        private void btnEnterAmount_Click(object sender, EventArgs e)
        {
            MessageBox.Show("AMOUNT ENTERED!");
        }

        private void txtQntty_MouseClick(object sender, MouseEventArgs e)
        {
            srchQntty.Clear();
        }

        private void txtQntty_MouseLeave(object sender, EventArgs e)
        {
            if (srchQntty.Text == "")
            {
                srchQntty.Text = "QUANTITY";
            }
        }

        private void RefreshProductData(string searchText = "")
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Use the SQL function to retrieve data from the INVENTORY table
                    string query = "SELECT * FROM dbo.GetProductData()";

                    if (!string.IsNullOrEmpty(searchText))
                    {
                        // Add a WHERE clause to the query if searchText is provided
                        query += " WHERE product_ID LIKE @SearchText OR product_name LIKE @SearchText OR price LIKE @SearchText OR category_ID LIKE @SearchText ";
                    }

                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        if (!string.IsNullOrEmpty(searchText))
                        {
                            cmd.Parameters.Add(new SqlParameter("@SearchText", "%" + searchText + "%"));
                        }

                        using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                        {
                            DataTable dataTable = new DataTable();
                            adapter.Fill(dataTable);
                            GridProduct.DataSource = dataTable;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions (e.g., display an error message)
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private void LoadProductData()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM [dbo].[GetProductData]()", connection))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);
                        GridProduct.DataSource = dataTable;
                    }
                }
            }
        }

        private void srchInventory_TextChanged(object sender, EventArgs e)
        {
            // Call RefreshInventoryData for the GridInventory
            RefreshProductData(srchPrd.Text);
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadProductData();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            RefreshProductData(srchPrd.Text);
        }
    }
}
