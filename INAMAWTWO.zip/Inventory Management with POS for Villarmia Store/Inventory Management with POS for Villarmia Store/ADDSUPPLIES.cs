﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory_Management_with_POS_for_Villarmia_Store
{
    public partial class ADDSUPPLIES : Form
    {
        private const string connectionString = "Data Source=LAPTOP-TV289K79\\SQLEXPRESS;Initial Catalog=villarmiaStore;Integrated Security=True";
        public ADDSUPPLIES()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are there no mistakes typed in the inputs?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                // Get the values from the text boxes
                int productID;
                if (int.TryParse(txtProductID.Text, out productID))
                {
                    int quantity;
                    if (int.TryParse(txtQuantity.Text, out quantity))
                    {
                        int supplierID;
                        if (int.TryParse(txtSupplierID.Text, out supplierID))
                        {
                            // Call the stored procedure to insert the supply data
                            using (SqlConnection connection = new SqlConnection(connectionString))
                            {
                                connection.Open();
                                using (SqlCommand command = new SqlCommand("InsertSupply", connection))
                                {
                                    command.CommandType = CommandType.StoredProcedure;
                                    command.Parameters.Add(new SqlParameter("@ProductID", productID));
                                    command.Parameters.Add(new SqlParameter("@Quantity", quantity));
                                    command.Parameters.Add(new SqlParameter("@SupplierID", supplierID));
                                    command.ExecuteNonQuery();
                                }
                            }

                            MessageBox.Show("Supply data inserted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("Invalid Supplier ID. Please enter a valid integer.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Invalid Quantity. Please enter a valid integer.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Invalid Product ID. Please enter a valid integer.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to Cancel?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                Supplies supp = new Supplies();
                supp.Show();
                this.Hide();
            }
        }

    }
}
