﻿namespace Inventory_Management_with_POS_for_Villarmia_Store
{
    partial class ADDinventory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ADDinventory));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dataGridProduct = new System.Windows.Forms.DataGridView();
            this.PrdID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PrdNm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Prc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CatgID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.ComboCatg = new System.Windows.Forms.ComboBox();
            this.txtPrc = new System.Windows.Forms.TextBox();
            this.txtPrdName = new System.Windows.Forms.TextBox();
            this.lblCategory = new System.Windows.Forms.Label();
            this.lblProduct = new System.Windows.Forms.Label();
            this.lblQnty = new System.Windows.Forms.Label();
            this.lblPrdNm = new System.Windows.Forms.Label();
            this.lblTITLE = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridProduct)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.lblTITLE);
            this.panel1.Location = new System.Drawing.Point(6, 6);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1402, 835);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackColor = System.Drawing.Color.Honeydew;
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.btnSave);
            this.panel2.Controls.Add(this.btnCancel);
            this.panel2.Controls.Add(this.ComboCatg);
            this.panel2.Controls.Add(this.txtPrc);
            this.panel2.Controls.Add(this.txtPrdName);
            this.panel2.Controls.Add(this.lblCategory);
            this.panel2.Controls.Add(this.lblProduct);
            this.panel2.Controls.Add(this.lblQnty);
            this.panel2.Controls.Add(this.lblPrdNm);
            this.panel2.Location = new System.Drawing.Point(19, 79);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1362, 735);
            this.panel2.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.Controls.Add(this.dataGridProduct);
            this.panel3.Location = new System.Drawing.Point(766, 49);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(579, 674);
            this.panel3.TabIndex = 4;
            // 
            // dataGridProduct
            // 
            this.dataGridProduct.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridProduct.ColumnHeadersHeight = 50;
            this.dataGridProduct.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.PrdID,
            this.PrdNm,
            this.Prc,
            this.CatgID});
            this.dataGridProduct.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridProduct.Location = new System.Drawing.Point(0, 0);
            this.dataGridProduct.Name = "dataGridProduct";
            this.dataGridProduct.RowHeadersVisible = false;
            this.dataGridProduct.RowHeadersWidth = 60;
            this.dataGridProduct.RowTemplate.Height = 24;
            this.dataGridProduct.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridProduct.Size = new System.Drawing.Size(579, 674);
            this.dataGridProduct.TabIndex = 0;
            // 
            // PrdID
            // 
            this.PrdID.HeaderText = "Product ID";
            this.PrdID.MinimumWidth = 6;
            this.PrdID.Name = "PrdID";
            // 
            // PrdNm
            // 
            this.PrdNm.HeaderText = "Product Name";
            this.PrdNm.MinimumWidth = 6;
            this.PrdNm.Name = "PrdNm";
            // 
            // Prc
            // 
            this.Prc.HeaderText = "Price";
            this.Prc.MinimumWidth = 6;
            this.Prc.Name = "Prc";
            // 
            // CatgID
            // 
            this.CatgID.HeaderText = "Category ID";
            this.CatgID.MinimumWidth = 6;
            this.CatgID.Name = "CatgID";
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnSave.BackColor = System.Drawing.Color.LightGreen;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(498, 649);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(196, 51);
            this.btnSave.TabIndex = 3;
            this.btnSave.Text = "SAVE";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnCancel.BackColor = System.Drawing.Color.IndianRed;
            this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.Location = new System.Drawing.Point(66, 649);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(196, 51);
            this.btnCancel.TabIndex = 3;
            this.btnCancel.Text = "CANCEL";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // ComboCatg
            // 
            this.ComboCatg.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ComboCatg.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ComboCatg.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ComboCatg.FormattingEnabled = true;
            this.ComboCatg.Items.AddRange(new object[] {
            "KITCHEN",
            "BATHROOM",
            "PLASTICWARES",
            "LAUNDRY",
            "MISCELLANEOUS",
            "SAMPLE CATEGORY"});
            this.ComboCatg.Location = new System.Drawing.Point(271, 502);
            this.ComboCatg.Name = "ComboCatg";
            this.ComboCatg.Size = new System.Drawing.Size(293, 39);
            this.ComboCatg.TabIndex = 2;
            // 
            // txtPrc
            // 
            this.txtPrc.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtPrc.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPrc.Location = new System.Drawing.Point(271, 287);
            this.txtPrc.Name = "txtPrc";
            this.txtPrc.Size = new System.Drawing.Size(432, 38);
            this.txtPrc.TabIndex = 1;
            // 
            // txtPrdName
            // 
            this.txtPrdName.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtPrdName.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPrdName.Location = new System.Drawing.Point(273, 50);
            this.txtPrdName.Name = "txtPrdName";
            this.txtPrdName.Size = new System.Drawing.Size(432, 38);
            this.txtPrdName.TabIndex = 1;
            // 
            // lblCategory
            // 
            this.lblCategory.AutoSize = true;
            this.lblCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCategory.Location = new System.Drawing.Point(90, 505);
            this.lblCategory.Name = "lblCategory";
            this.lblCategory.Size = new System.Drawing.Size(154, 32);
            this.lblCategory.TabIndex = 0;
            this.lblCategory.Text = "Category :";
            // 
            // lblProduct
            // 
            this.lblProduct.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblProduct.AutoSize = true;
            this.lblProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProduct.Location = new System.Drawing.Point(832, 80);
            this.lblProduct.Name = "lblProduct";
            this.lblProduct.Size = new System.Drawing.Size(159, 32);
            this.lblProduct.TabIndex = 0;
            this.lblProduct.Text = "PRODUCT";
            // 
            // lblQnty
            // 
            this.lblQnty.AutoSize = true;
            this.lblQnty.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQnty.Location = new System.Drawing.Point(141, 290);
            this.lblQnty.Name = "lblQnty";
            this.lblQnty.Size = new System.Drawing.Size(101, 32);
            this.lblQnty.TabIndex = 0;
            this.lblQnty.Text = "Price :";
            // 
            // lblPrdNm
            // 
            this.lblPrdNm.AutoSize = true;
            this.lblPrdNm.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrdNm.Location = new System.Drawing.Point(24, 49);
            this.lblPrdNm.Name = "lblPrdNm";
            this.lblPrdNm.Size = new System.Drawing.Size(223, 32);
            this.lblPrdNm.TabIndex = 0;
            this.lblPrdNm.Text = "Product Name :";
            // 
            // lblTITLE
            // 
            this.lblTITLE.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblTITLE.AutoSize = true;
            this.lblTITLE.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTITLE.Location = new System.Drawing.Point(608, 20);
            this.lblTITLE.Name = "lblTITLE";
            this.lblTITLE.Size = new System.Drawing.Size(303, 42);
            this.lblTITLE.TabIndex = 0;
            this.lblTITLE.Text = "ADD PRODUCT";
            // 
            // ADDinventory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.ForestGreen;
            this.ClientSize = new System.Drawing.Size(1416, 848);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ADDinventory";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ADDinventory";
            this.TopMost = true;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridProduct)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblCategory;
        private System.Windows.Forms.Label lblQnty;
        private System.Windows.Forms.Label lblPrdNm;
        private System.Windows.Forms.Label lblTITLE;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.ComboBox ComboCatg;
        private System.Windows.Forms.TextBox txtPrc;
        private System.Windows.Forms.TextBox txtPrdName;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DataGridView dataGridProduct;
        private System.Windows.Forms.DataGridViewTextBoxColumn PrdID;
        private System.Windows.Forms.DataGridViewTextBoxColumn PrdNm;
        private System.Windows.Forms.DataGridViewTextBoxColumn Prc;
        private System.Windows.Forms.DataGridViewTextBoxColumn CatgID;
        private System.Windows.Forms.Label lblProduct;
    }
}