﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory_Management_with_POS_for_Villarmia_Store
{
    public partial class DeleteSupplies : Form
    {
        public DeleteSupplies()
        {
            InitializeComponent();
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to DELETE this Supply?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                if (MessageBox.Show("THE SAID SUPPLY WILL BE REMOVED TO THE DATABASE! Do you still want to continue?", "WARNING MESSAGE!!!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    MessageBox.Show("Supply Successfully Deleted!");
                    Supplies supp = new Supplies();
                    supp.Show();
                    this.Hide();
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to Cancel?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                Supplies sup = new Supplies();
                sup.Show();
                this.Hide();
            }
        }

        private void txtSrch_MouseClick(object sender, MouseEventArgs e)
        {
            txtSrch.Clear();
        }

        private void txtSrch_MouseLeave(object sender, EventArgs e)
        {
            if (txtSrch.Text == "")
            {
                txtSrch.Text = "SEARCH";
            }
        }
    }
}
