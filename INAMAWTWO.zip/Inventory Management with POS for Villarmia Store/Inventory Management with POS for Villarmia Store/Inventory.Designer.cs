﻿namespace Inventory_Management_with_POS_for_Villarmia_Store
{
    partial class Inventory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Inventory));
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblPRODUCT = new System.Windows.Forms.Label();
            this.lblINVENTORY = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dataGridProduct = new System.Windows.Forms.DataGridView();
            this.PrdtID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PrdName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Prc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CatgryID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnDELETE = new System.Windows.Forms.Button();
            this.btnREFRESH = new System.Windows.Forms.Button();
            this.btnEditInv = new System.Windows.Forms.Button();
            this.btnEditProd = new System.Windows.Forms.Button();
            this.btnADDPrd = new System.Windows.Forms.Button();
            this.srchInventory = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dataGridInventory = new System.Windows.Forms.DataGridView();
            this.PrdID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PrdNm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Qntty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CatgID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StckNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RefID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DelDT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.mENUToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eXITToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vIEWSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pOSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sUPPLIESToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eMPLOYEEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridProduct)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridInventory)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.panel1.Controls.Add(this.lblPRODUCT);
            this.panel1.Controls.Add(this.lblINVENTORY);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.btnDELETE);
            this.panel1.Controls.Add(this.btnREFRESH);
            this.panel1.Controls.Add(this.btnEditInv);
            this.panel1.Controls.Add(this.btnEditProd);
            this.panel1.Controls.Add(this.btnADDPrd);
            this.panel1.Controls.Add(this.srchInventory);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(0, 31);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1237, 594);
            this.panel1.TabIndex = 0;
            // 
            // lblPRODUCT
            // 
            this.lblPRODUCT.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblPRODUCT.AutoSize = true;
            this.lblPRODUCT.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPRODUCT.Location = new System.Drawing.Point(830, 86);
            this.lblPRODUCT.Name = "lblPRODUCT";
            this.lblPRODUCT.Size = new System.Drawing.Size(159, 32);
            this.lblPRODUCT.TabIndex = 1;
            this.lblPRODUCT.Text = "PRODUCT";
            // 
            // lblINVENTORY
            // 
            this.lblINVENTORY.AutoSize = true;
            this.lblINVENTORY.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblINVENTORY.Location = new System.Drawing.Point(22, 84);
            this.lblINVENTORY.Name = "lblINVENTORY";
            this.lblINVENTORY.Size = new System.Drawing.Size(186, 32);
            this.lblINVENTORY.TabIndex = 1;
            this.lblINVENTORY.Text = "INVENTORY";
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.Controls.Add(this.dataGridProduct);
            this.panel3.Location = new System.Drawing.Point(817, 121);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(407, 456);
            this.panel3.TabIndex = 3;
            // 
            // dataGridProduct
            // 
            this.dataGridProduct.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridProduct.ColumnHeadersHeight = 50;
            this.dataGridProduct.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.PrdtID,
            this.PrdName,
            this.Prc,
            this.CatgryID});
            this.dataGridProduct.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridProduct.Location = new System.Drawing.Point(0, 0);
            this.dataGridProduct.Name = "dataGridProduct";
            this.dataGridProduct.RowHeadersVisible = false;
            this.dataGridProduct.RowHeadersWidth = 60;
            this.dataGridProduct.RowTemplate.Height = 24;
            this.dataGridProduct.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridProduct.Size = new System.Drawing.Size(407, 456);
            this.dataGridProduct.TabIndex = 0;
            // 
            // PrdtID
            // 
            this.PrdtID.HeaderText = "Product ID";
            this.PrdtID.MinimumWidth = 6;
            this.PrdtID.Name = "PrdtID";
            // 
            // PrdName
            // 
            this.PrdName.HeaderText = "Product Name";
            this.PrdName.MinimumWidth = 6;
            this.PrdName.Name = "PrdName";
            // 
            // Prc
            // 
            this.Prc.HeaderText = "Price";
            this.Prc.MinimumWidth = 6;
            this.Prc.Name = "Prc";
            // 
            // CatgryID
            // 
            this.CatgryID.HeaderText = "Category ID";
            this.CatgryID.MinimumWidth = 6;
            this.CatgryID.Name = "CatgryID";
            // 
            // btnDELETE
            // 
            this.btnDELETE.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDELETE.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDELETE.Location = new System.Drawing.Point(1107, 24);
            this.btnDELETE.Name = "btnDELETE";
            this.btnDELETE.Size = new System.Drawing.Size(117, 41);
            this.btnDELETE.TabIndex = 2;
            this.btnDELETE.Text = "DELETE";
            this.btnDELETE.UseVisualStyleBackColor = true;
            this.btnDELETE.Click += new System.EventHandler(this.btnDELETE_Click);
            // 
            // btnREFRESH
            // 
            this.btnREFRESH.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnREFRESH.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnREFRESH.Location = new System.Drawing.Point(961, 24);
            this.btnREFRESH.Name = "btnREFRESH";
            this.btnREFRESH.Size = new System.Drawing.Size(117, 41);
            this.btnREFRESH.TabIndex = 2;
            this.btnREFRESH.Text = "REFRESH";
            this.btnREFRESH.UseVisualStyleBackColor = true;
            // 
            // btnEditInv
            // 
            this.btnEditInv.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnEditInv.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditInv.Location = new System.Drawing.Point(508, 24);
            this.btnEditInv.Name = "btnEditInv";
            this.btnEditInv.Size = new System.Drawing.Size(202, 41);
            this.btnEditInv.TabIndex = 2;
            this.btnEditInv.Text = "EDIT INVENTORY";
            this.btnEditInv.UseVisualStyleBackColor = true;
            this.btnEditInv.Click += new System.EventHandler(this.btnEditInv_Click);
            // 
            // btnEditProd
            // 
            this.btnEditProd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnEditProd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditProd.Location = new System.Drawing.Point(739, 24);
            this.btnEditProd.Name = "btnEditProd";
            this.btnEditProd.Size = new System.Drawing.Size(195, 41);
            this.btnEditProd.TabIndex = 2;
            this.btnEditProd.Text = "EDIT PRODUCT";
            this.btnEditProd.UseVisualStyleBackColor = true;
            this.btnEditProd.Click += new System.EventHandler(this.btnEditProd_Click);
            // 
            // btnADDPrd
            // 
            this.btnADDPrd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnADDPrd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnADDPrd.Location = new System.Drawing.Point(267, 24);
            this.btnADDPrd.Name = "btnADDPrd";
            this.btnADDPrd.Size = new System.Drawing.Size(208, 41);
            this.btnADDPrd.TabIndex = 2;
            this.btnADDPrd.Text = "ADD PRODUCT";
            this.btnADDPrd.UseVisualStyleBackColor = true;
            this.btnADDPrd.Click += new System.EventHandler(this.btnADDPrd_Click);
            // 
            // srchInventory
            // 
            this.srchInventory.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.srchInventory.Location = new System.Drawing.Point(28, 31);
            this.srchInventory.Name = "srchInventory";
            this.srchInventory.Size = new System.Drawing.Size(497, 34);
            this.srchInventory.TabIndex = 1;
            this.srchInventory.Text = "SEARCH";
            this.srchInventory.MouseClick += new System.Windows.Forms.MouseEventHandler(this.srchInventory_MouseClick);
            this.srchInventory.TextChanged += new System.EventHandler(this.srchInventory_TextChanged);
            this.srchInventory.MouseLeave += new System.EventHandler(this.srchInventory_MouseLeave);
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.Controls.Add(this.dataGridInventory);
            this.panel2.Location = new System.Drawing.Point(12, 119);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(799, 458);
            this.panel2.TabIndex = 0;
            // 
            // dataGridInventory
            // 
            this.dataGridInventory.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridInventory.ColumnHeadersHeight = 50;
            this.dataGridInventory.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.PrdID,
            this.PrdNm,
            this.Qntty,
            this.CatgID,
            this.StckNo,
            this.RefID,
            this.DelDT});
            this.dataGridInventory.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridInventory.Location = new System.Drawing.Point(0, 0);
            this.dataGridInventory.Name = "dataGridInventory";
            this.dataGridInventory.RowHeadersVisible = false;
            this.dataGridInventory.RowHeadersWidth = 60;
            this.dataGridInventory.RowTemplate.Height = 24;
            this.dataGridInventory.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridInventory.Size = new System.Drawing.Size(799, 458);
            this.dataGridInventory.TabIndex = 0;
            // 
            // PrdID
            // 
            this.PrdID.HeaderText = "Product ID";
            this.PrdID.MinimumWidth = 6;
            this.PrdID.Name = "PrdID";
            // 
            // PrdNm
            // 
            this.PrdNm.HeaderText = "Product Name";
            this.PrdNm.MinimumWidth = 6;
            this.PrdNm.Name = "PrdNm";
            // 
            // Qntty
            // 
            this.Qntty.HeaderText = "Quantity";
            this.Qntty.MinimumWidth = 6;
            this.Qntty.Name = "Qntty";
            // 
            // CatgID
            // 
            this.CatgID.HeaderText = "Category ID";
            this.CatgID.MinimumWidth = 6;
            this.CatgID.Name = "CatgID";
            // 
            // StckNo
            // 
            this.StckNo.HeaderText = "Stock No.";
            this.StckNo.MinimumWidth = 6;
            this.StckNo.Name = "StckNo";
            // 
            // RefID
            // 
            this.RefID.HeaderText = "Referential ID";
            this.RefID.MinimumWidth = 6;
            this.RefID.Name = "RefID";
            // 
            // DelDT
            // 
            this.DelDT.HeaderText = "Delivery Date";
            this.DelDT.MinimumWidth = 6;
            this.DelDT.Name = "DelDT";
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Aquamarine;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mENUToolStripMenuItem,
            this.vIEWSToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1237, 28);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // mENUToolStripMenuItem
            // 
            this.mENUToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.eXITToolStripMenuItem});
            this.mENUToolStripMenuItem.Name = "mENUToolStripMenuItem";
            this.mENUToolStripMenuItem.Size = new System.Drawing.Size(65, 24);
            this.mENUToolStripMenuItem.Text = "MENU";
            // 
            // eXITToolStripMenuItem
            // 
            this.eXITToolStripMenuItem.Name = "eXITToolStripMenuItem";
            this.eXITToolStripMenuItem.Size = new System.Drawing.Size(121, 26);
            this.eXITToolStripMenuItem.Text = "EXIT";
            this.eXITToolStripMenuItem.Click += new System.EventHandler(this.eXITToolStripMenuItem_Click);
            // 
            // vIEWSToolStripMenuItem
            // 
            this.vIEWSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pOSToolStripMenuItem,
            this.sUPPLIESToolStripMenuItem,
            this.eMPLOYEEToolStripMenuItem});
            this.vIEWSToolStripMenuItem.Name = "vIEWSToolStripMenuItem";
            this.vIEWSToolStripMenuItem.Size = new System.Drawing.Size(66, 24);
            this.vIEWSToolStripMenuItem.Text = "GO TO";
            // 
            // pOSToolStripMenuItem
            // 
            this.pOSToolStripMenuItem.Name = "pOSToolStripMenuItem";
            this.pOSToolStripMenuItem.Size = new System.Drawing.Size(162, 26);
            this.pOSToolStripMenuItem.Text = "POS";
            this.pOSToolStripMenuItem.Click += new System.EventHandler(this.pOSToolStripMenuItem_Click);
            // 
            // sUPPLIESToolStripMenuItem
            // 
            this.sUPPLIESToolStripMenuItem.Name = "sUPPLIESToolStripMenuItem";
            this.sUPPLIESToolStripMenuItem.Size = new System.Drawing.Size(162, 26);
            this.sUPPLIESToolStripMenuItem.Text = "SUPPLIES";
            this.sUPPLIESToolStripMenuItem.Click += new System.EventHandler(this.sUPPLIESToolStripMenuItem_Click);
            // 
            // eMPLOYEEToolStripMenuItem
            // 
            this.eMPLOYEEToolStripMenuItem.Name = "eMPLOYEEToolStripMenuItem";
            this.eMPLOYEEToolStripMenuItem.Size = new System.Drawing.Size(162, 26);
            this.eMPLOYEEToolStripMenuItem.Text = "EMPLOYEE";
            this.eMPLOYEEToolStripMenuItem.Click += new System.EventHandler(this.eMPLOYEEToolStripMenuItem_Click);
            // 
            // Inventory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.ForestGreen;
            this.ClientSize = new System.Drawing.Size(1237, 637);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Inventory";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Inventory";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridProduct)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridInventory)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mENUToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eXITToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vIEWSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pOSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sUPPLIESToolStripMenuItem;
        private System.Windows.Forms.Button btnDELETE;
        private System.Windows.Forms.Button btnREFRESH;
        private System.Windows.Forms.Button btnEditProd;
        private System.Windows.Forms.Button btnADDPrd;
        private System.Windows.Forms.TextBox srchInventory;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView dataGridInventory;
        private System.Windows.Forms.DataGridViewTextBoxColumn PrdID;
        private System.Windows.Forms.DataGridViewTextBoxColumn PrdNm;
        private System.Windows.Forms.DataGridViewTextBoxColumn Qntty;
        private System.Windows.Forms.DataGridViewTextBoxColumn CatgID;
        private System.Windows.Forms.DataGridViewTextBoxColumn StckNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn RefID;
        private System.Windows.Forms.DataGridViewTextBoxColumn DelDT;
        private System.Windows.Forms.Label lblPRODUCT;
        private System.Windows.Forms.Label lblINVENTORY;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DataGridView dataGridProduct;
        private System.Windows.Forms.DataGridViewTextBoxColumn PrdtID;
        private System.Windows.Forms.DataGridViewTextBoxColumn PrdName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Prc;
        private System.Windows.Forms.DataGridViewTextBoxColumn CatgryID;
        private System.Windows.Forms.Button btnEditInv;
        private System.Windows.Forms.ToolStripMenuItem eMPLOYEEToolStripMenuItem;
    }
}