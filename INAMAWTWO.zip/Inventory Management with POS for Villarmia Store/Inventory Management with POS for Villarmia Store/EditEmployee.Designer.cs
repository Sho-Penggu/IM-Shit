﻿namespace Inventory_Management_with_POS_for_Villarmia_Store
{
    partial class EditEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EditEmployee));
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblTITLE = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.ComboPosi = new System.Windows.Forms.ComboBox();
            this.txtPsky = new System.Windows.Forms.TextBox();
            this.txtUsNm = new System.Windows.Forms.TextBox();
            this.txtLn = new System.Windows.Forms.TextBox();
            this.txtSrch = new System.Windows.Forms.TextBox();
            this.txtFn = new System.Windows.Forms.TextBox();
            this.lblPsky = new System.Windows.Forms.Label();
            this.lblUsNm = new System.Windows.Forms.Label();
            this.lblPosi = new System.Windows.Forms.Label();
            this.lblLn = new System.Windows.Forms.Label();
            this.lblStffID = new System.Windows.Forms.Label();
            this.lblFn = new System.Windows.Forms.Label();
            this.lblEMPLOYEE = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.StffID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StffFn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StffLn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StffPosi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UsNm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Psky = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.panel1.Controls.Add(this.lblTITLE);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(6, 6);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1472, 859);
            this.panel1.TabIndex = 0;
            // 
            // lblTITLE
            // 
            this.lblTITLE.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblTITLE.AutoSize = true;
            this.lblTITLE.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTITLE.Location = new System.Drawing.Point(623, 20);
            this.lblTITLE.Name = "lblTITLE";
            this.lblTITLE.Size = new System.Drawing.Size(331, 42);
            this.lblTITLE.TabIndex = 1;
            this.lblTITLE.Text = "EDIT EMPLOYEE";
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackColor = System.Drawing.Color.Honeydew;
            this.panel2.Controls.Add(this.btnSave);
            this.panel2.Controls.Add(this.btnCancel);
            this.panel2.Controls.Add(this.ComboPosi);
            this.panel2.Controls.Add(this.txtPsky);
            this.panel2.Controls.Add(this.txtUsNm);
            this.panel2.Controls.Add(this.txtLn);
            this.panel2.Controls.Add(this.txtSrch);
            this.panel2.Controls.Add(this.txtFn);
            this.panel2.Controls.Add(this.lblPsky);
            this.panel2.Controls.Add(this.lblUsNm);
            this.panel2.Controls.Add(this.lblPosi);
            this.panel2.Controls.Add(this.lblLn);
            this.panel2.Controls.Add(this.lblStffID);
            this.panel2.Controls.Add(this.lblFn);
            this.panel2.Controls.Add(this.lblEMPLOYEE);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Location = new System.Drawing.Point(19, 79);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1432, 759);
            this.panel2.TabIndex = 0;
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnSave.BackColor = System.Drawing.Color.LightGreen;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(496, 679);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(196, 51);
            this.btnSave.TabIndex = 4;
            this.btnSave.Text = "SAVE";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnCancel.BackColor = System.Drawing.Color.IndianRed;
            this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.Location = new System.Drawing.Point(64, 679);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(196, 51);
            this.btnCancel.TabIndex = 4;
            this.btnCancel.Text = "CANCEL";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // ComboPosi
            // 
            this.ComboPosi.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ComboPosi.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ComboPosi.FormattingEnabled = true;
            this.ComboPosi.Location = new System.Drawing.Point(226, 331);
            this.ComboPosi.Name = "ComboPosi";
            this.ComboPosi.Size = new System.Drawing.Size(271, 39);
            this.ComboPosi.TabIndex = 3;
            // 
            // txtPsky
            // 
            this.txtPsky.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtPsky.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPsky.Location = new System.Drawing.Point(224, 535);
            this.txtPsky.Name = "txtPsky";
            this.txtPsky.Size = new System.Drawing.Size(424, 38);
            this.txtPsky.TabIndex = 2;
            // 
            // txtUsNm
            // 
            this.txtUsNm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtUsNm.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUsNm.Location = new System.Drawing.Point(226, 433);
            this.txtUsNm.Name = "txtUsNm";
            this.txtUsNm.Size = new System.Drawing.Size(424, 38);
            this.txtUsNm.TabIndex = 2;
            // 
            // txtLn
            // 
            this.txtLn.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtLn.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLn.Location = new System.Drawing.Point(226, 229);
            this.txtLn.Name = "txtLn";
            this.txtLn.Size = new System.Drawing.Size(424, 38);
            this.txtLn.TabIndex = 2;
            // 
            // txtSrch
            // 
            this.txtSrch.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtSrch.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSrch.Location = new System.Drawing.Point(226, 46);
            this.txtSrch.Name = "txtSrch";
            this.txtSrch.Size = new System.Drawing.Size(228, 38);
            this.txtSrch.TabIndex = 2;
            // 
            // txtFn
            // 
            this.txtFn.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtFn.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFn.Location = new System.Drawing.Point(226, 136);
            this.txtFn.Name = "txtFn";
            this.txtFn.Size = new System.Drawing.Size(424, 38);
            this.txtFn.TabIndex = 2;
            // 
            // lblPsky
            // 
            this.lblPsky.AutoSize = true;
            this.lblPsky.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPsky.Location = new System.Drawing.Point(58, 538);
            this.lblPsky.Name = "lblPsky";
            this.lblPsky.Size = new System.Drawing.Size(145, 32);
            this.lblPsky.TabIndex = 1;
            this.lblPsky.Text = "Passkey :";
            // 
            // lblUsNm
            // 
            this.lblUsNm.AutoSize = true;
            this.lblUsNm.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUsNm.Location = new System.Drawing.Point(36, 436);
            this.lblUsNm.Name = "lblUsNm";
            this.lblUsNm.Size = new System.Drawing.Size(169, 32);
            this.lblUsNm.TabIndex = 1;
            this.lblUsNm.Text = "Username :";
            // 
            // lblPosi
            // 
            this.lblPosi.AutoSize = true;
            this.lblPosi.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPosi.Location = new System.Drawing.Point(63, 334);
            this.lblPosi.Name = "lblPosi";
            this.lblPosi.Size = new System.Drawing.Size(142, 32);
            this.lblPosi.TabIndex = 1;
            this.lblPosi.Text = "Position :";
            // 
            // lblLn
            // 
            this.lblLn.AutoSize = true;
            this.lblLn.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLn.Location = new System.Drawing.Point(29, 232);
            this.lblLn.Name = "lblLn";
            this.lblLn.Size = new System.Drawing.Size(176, 32);
            this.lblLn.TabIndex = 1;
            this.lblLn.Text = "Last Name :";
            // 
            // lblStffID
            // 
            this.lblStffID.AutoSize = true;
            this.lblStffID.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStffID.Location = new System.Drawing.Point(41, 49);
            this.lblStffID.Name = "lblStffID";
            this.lblStffID.Size = new System.Drawing.Size(164, 32);
            this.lblStffID.TabIndex = 1;
            this.lblStffID.Text = "Search ID :";
            // 
            // lblFn
            // 
            this.lblFn.AutoSize = true;
            this.lblFn.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFn.Location = new System.Drawing.Point(27, 139);
            this.lblFn.Name = "lblFn";
            this.lblFn.Size = new System.Drawing.Size(178, 32);
            this.lblFn.TabIndex = 1;
            this.lblFn.Text = "First Name :";
            // 
            // lblEMPLOYEE
            // 
            this.lblEMPLOYEE.AutoSize = true;
            this.lblEMPLOYEE.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEMPLOYEE.Location = new System.Drawing.Point(776, 14);
            this.lblEMPLOYEE.Name = "lblEMPLOYEE";
            this.lblEMPLOYEE.Size = new System.Drawing.Size(178, 32);
            this.lblEMPLOYEE.TabIndex = 1;
            this.lblEMPLOYEE.Text = "EMPLOYEE";
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.Controls.Add(this.dataGridView1);
            this.panel3.Location = new System.Drawing.Point(766, 49);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(649, 698);
            this.panel3.TabIndex = 0;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeight = 50;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.StffID,
            this.StffFn,
            this.StffLn,
            this.StffPosi,
            this.UsNm,
            this.Psky});
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidth = 60;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(649, 698);
            this.dataGridView1.TabIndex = 0;
            // 
            // StffID
            // 
            this.StffID.HeaderText = "Staff ID";
            this.StffID.MinimumWidth = 6;
            this.StffID.Name = "StffID";
            // 
            // StffFn
            // 
            this.StffFn.HeaderText = "Staff First Name";
            this.StffFn.MinimumWidth = 6;
            this.StffFn.Name = "StffFn";
            // 
            // StffLn
            // 
            this.StffLn.HeaderText = "Staff Last Name";
            this.StffLn.MinimumWidth = 6;
            this.StffLn.Name = "StffLn";
            // 
            // StffPosi
            // 
            this.StffPosi.HeaderText = "Staff Position";
            this.StffPosi.MinimumWidth = 6;
            this.StffPosi.Name = "StffPosi";
            // 
            // UsNm
            // 
            this.UsNm.HeaderText = "Username";
            this.UsNm.MinimumWidth = 6;
            this.UsNm.Name = "UsNm";
            // 
            // Psky
            // 
            this.Psky.HeaderText = "Passkey";
            this.Psky.MinimumWidth = 6;
            this.Psky.Name = "Psky";
            // 
            // EditEmployee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.ForestGreen;
            this.ClientSize = new System.Drawing.Size(1486, 872);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "EditEmployee";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AddEmployee";
            this.TopMost = true;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblTITLE;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lblEMPLOYEE;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox txtFn;
        private System.Windows.Forms.Label lblPsky;
        private System.Windows.Forms.Label lblUsNm;
        private System.Windows.Forms.Label lblPosi;
        private System.Windows.Forms.Label lblLn;
        private System.Windows.Forms.Label lblFn;
        private System.Windows.Forms.DataGridViewTextBoxColumn StffID;
        private System.Windows.Forms.DataGridViewTextBoxColumn StffFn;
        private System.Windows.Forms.DataGridViewTextBoxColumn StffLn;
        private System.Windows.Forms.DataGridViewTextBoxColumn StffPosi;
        private System.Windows.Forms.DataGridViewTextBoxColumn UsNm;
        private System.Windows.Forms.DataGridViewTextBoxColumn Psky;
        private System.Windows.Forms.TextBox txtPsky;
        private System.Windows.Forms.TextBox txtUsNm;
        private System.Windows.Forms.TextBox txtLn;
        private System.Windows.Forms.TextBox txtSrch;
        private System.Windows.Forms.Label lblStffID;
        private System.Windows.Forms.ComboBox ComboPosi;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
    }
}