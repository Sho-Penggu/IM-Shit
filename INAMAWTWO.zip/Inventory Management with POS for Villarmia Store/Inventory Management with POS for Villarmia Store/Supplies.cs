﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory_Management_with_POS_for_Villarmia_Store
{
    public partial class Supplies : Form
    {
        private const string connectionString = "Data Source=LAPTOP-TV289K79\\SQLEXPRESS;Initial Catalog=villarmiaStore;Integrated Security=True";
        public Supplies()
        {
            InitializeComponent();
        }

        private void eXITToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void iNVENTORYToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Inventory inv = new Inventory();
            inv.Show();
            this.Hide();
        }

        private void pOSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            POS pos = new POS();
            pos.Show();
            this.Hide();
        }

        private void srchProduct_MouseClick(object sender, MouseEventArgs e)
        {
            srchSupplies.Clear();
        }

        private void srchProduct_MouseLeave(object sender, EventArgs e)
        {
            if (srchSupplies.Text == "")
            {
                srchSupplies.Text = "SEARCH";
            }
        }

        private void btnAddSupply_Click(object sender, EventArgs e)
        {
           
            //Pop-up Confirm 1st
            Supplies sup = new Supplies();
            try
            {
                using (ADDSUPPLIES ads = new ADDSUPPLIES())
                {
                    sup.StartPosition = FormStartPosition.Manual;
                    sup.FormBorderStyle = FormBorderStyle.None;
                    sup.Opacity = 77.77;
                    sup.BackColor = Color.Black;
                    sup.WindowState = FormWindowState.Maximized;
                    sup.TopMost = true;
                    sup.Location = this.Location;
                    sup.ShowInTaskbar = false;
                    sup.Show();

                    ads.Owner = sup;
                    ads.ShowDialog();

                    sup.Dispose();
                    this.Hide();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                sup.Dispose();
            }
        }

        private void btnAddSupplier_Click(object sender, EventArgs e)
        {
            //Pop-up Confirm 1st
            Supplies sup = new Supplies();
            try
            {
                using (AddSupplier adr = new AddSupplier())
                {
                    sup.StartPosition = FormStartPosition.Manual;
                    sup.FormBorderStyle = FormBorderStyle.None;
                    sup.Opacity = 77.77;
                    sup.BackColor = Color.Black;
                    sup.WindowState = FormWindowState.Maximized;
                    sup.TopMost = true;
                    sup.Location = this.Location;
                    sup.ShowInTaskbar = false;
                    sup.Show();

                    adr.Owner = sup;
                    adr.ShowDialog();

                    sup.Dispose();
                    this.Hide();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                sup.Dispose();
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            //Pop-up Confirm 1st
            Supplies sup = new Supplies();
            try
            {
                using (EditSupplier eds = new EditSupplier())
                {
                    sup.StartPosition = FormStartPosition.Manual;
                    sup.FormBorderStyle = FormBorderStyle.None;
                    sup.Opacity = 77.77;
                    sup.BackColor = Color.Black;
                    sup.WindowState = FormWindowState.Maximized;
                    sup.TopMost = true;
                    sup.Location = this.Location;
                    sup.ShowInTaskbar = false;
                    sup.Show();

                    eds.Owner = sup;
                    eds.ShowDialog();

                    sup.Dispose();
                    this.Hide();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                sup.Dispose();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            //Pop-up Confirm 1st
            Supplies sup = new Supplies();
            try
            {
                using (DeleteSupplies dels = new DeleteSupplies())
                {
                    sup.StartPosition = FormStartPosition.Manual;
                    sup.FormBorderStyle = FormBorderStyle.None;
                    sup.Opacity = 77.77;
                    sup.BackColor = Color.Black;
                    sup.WindowState = FormWindowState.Maximized;
                    sup.TopMost = true;
                    sup.Location = this.Location;
                    sup.ShowInTaskbar = false;
                    sup.Show();

                    dels.Owner = sup;
                    dels.ShowDialog();

                    sup.Dispose();
                    this.Hide();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                sup.Dispose();
            }
        }

        private void eMPLOYEEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Employee emp = new Employee();
            emp.Show();
            this.Hide();
        }


        //QUERY

        // Refresh data in DataGridViews
        private void RefreshData(DataGridView dataGridView, string searchText = "")
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = dataGridView == dataGridSupplies
                        ? "SELECT * FROM GetSupplyData()"
                        : "SELECT * FROM GetSupplierData()";

                    if (!string.IsNullOrEmpty(searchText))
                    {
                        if (dataGridView == dataGridSupplies)
                        {
                            query += " WHERE supply_ID LIKE @SearchText OR product_ID LIKE @SearchText OR quantity LIKE @SearchText OR supplier_ID LIKE @SearchText";
                        }
                        else
                        {
                            query += " WHERE supplier_ID LIKE @SearchText OR company_name LIKE @SearchText OR comp_address LIKE @SearchText OR phone_number LIKE @SearchText";
                        }
                    }

                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        if (!string.IsNullOrEmpty(searchText))
                        {
                            cmd.Parameters.Add(new SqlParameter("@SearchText", "%" + searchText + "%"));
                        }

                        using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                        {
                            DataTable dataTable = new DataTable();
                            adapter.Fill(dataTable);
                            dataGridView.DataSource = dataTable;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions (e.g., display an error message)
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private void LoadSupplierData()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM [dbo].[GetSupplierData]()", connection))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);
                        dataGridSupplier.DataSource = dataTable;
                    }
                }
            }
        }

        private void LoadSupplyData()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM [dbo].[GetSupplyData]()", connection))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);
                        dataGridSupplies.DataSource = dataTable;
                    }
                }
            }
        }

        private void srchSupplies_TextChanged(object sender, EventArgs e)
        {
            RefreshData(dataGridSupplies, srchSupplies.Text);
        }

        private void srchSupplier_TextChanged(object sender, EventArgs e)
        {
            RefreshData(dataGridSupplier, srchSupplies.Text);
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadSupplierData();
            LoadSupplyData();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            RefreshData(dataGridSupplies, srchSupplies.Text);
            RefreshData(dataGridSupplier, srchSupplies.Text);
        }
    }
}
