﻿namespace Inventory_Management_with_POS_for_Villarmia_Store
{
    partial class Supplies
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Supplies));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.mENUToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eXITToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gOTOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iNVENTORYToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pOSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eMPLOYEEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dataGridSupplies = new System.Windows.Forms.DataGridView();
            this.SupplyID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PrdID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Qntty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SuPID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dataGridSupplier = new System.Windows.Forms.DataGridView();
            this.SuPlyrID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CmpNm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Addrss = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PhnNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.lblSupplier = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.lblSupply = new System.Windows.Forms.Label();
            this.btnEditSupplier = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnAddSupplier = new System.Windows.Forms.Button();
            this.btnAddSupply = new System.Windows.Forms.Button();
            this.srchSupplies = new System.Windows.Forms.TextBox();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridSupplies)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridSupplier)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Aquamarine;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mENUToolStripMenuItem,
            this.gOTOToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1224, 30);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // mENUToolStripMenuItem
            // 
            this.mENUToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.eXITToolStripMenuItem});
            this.mENUToolStripMenuItem.Name = "mENUToolStripMenuItem";
            this.mENUToolStripMenuItem.Size = new System.Drawing.Size(65, 26);
            this.mENUToolStripMenuItem.Text = "MENU";
            // 
            // eXITToolStripMenuItem
            // 
            this.eXITToolStripMenuItem.Name = "eXITToolStripMenuItem";
            this.eXITToolStripMenuItem.Size = new System.Drawing.Size(121, 26);
            this.eXITToolStripMenuItem.Text = "EXIT";
            this.eXITToolStripMenuItem.Click += new System.EventHandler(this.eXITToolStripMenuItem_Click);
            // 
            // gOTOToolStripMenuItem
            // 
            this.gOTOToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.iNVENTORYToolStripMenuItem,
            this.pOSToolStripMenuItem,
            this.eMPLOYEEToolStripMenuItem});
            this.gOTOToolStripMenuItem.Name = "gOTOToolStripMenuItem";
            this.gOTOToolStripMenuItem.Size = new System.Drawing.Size(66, 26);
            this.gOTOToolStripMenuItem.Text = "GO TO";
            // 
            // iNVENTORYToolStripMenuItem
            // 
            this.iNVENTORYToolStripMenuItem.Name = "iNVENTORYToolStripMenuItem";
            this.iNVENTORYToolStripMenuItem.Size = new System.Drawing.Size(170, 26);
            this.iNVENTORYToolStripMenuItem.Text = "INVENTORY";
            this.iNVENTORYToolStripMenuItem.Click += new System.EventHandler(this.iNVENTORYToolStripMenuItem_Click);
            // 
            // pOSToolStripMenuItem
            // 
            this.pOSToolStripMenuItem.Name = "pOSToolStripMenuItem";
            this.pOSToolStripMenuItem.Size = new System.Drawing.Size(170, 26);
            this.pOSToolStripMenuItem.Text = "POS";
            this.pOSToolStripMenuItem.Click += new System.EventHandler(this.pOSToolStripMenuItem_Click);
            // 
            // eMPLOYEEToolStripMenuItem
            // 
            this.eMPLOYEEToolStripMenuItem.Name = "eMPLOYEEToolStripMenuItem";
            this.eMPLOYEEToolStripMenuItem.Size = new System.Drawing.Size(170, 26);
            this.eMPLOYEEToolStripMenuItem.Text = "EMPLOYEE";
            this.eMPLOYEEToolStripMenuItem.Click += new System.EventHandler(this.eMPLOYEEToolStripMenuItem_Click);
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.panel1.Controls.Add(this.dataGridSupplies);
            this.panel1.Location = new System.Drawing.Point(3, 41);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1003, 530);
            this.panel1.TabIndex = 1;
            // 
            // dataGridSupplies
            // 
            this.dataGridSupplies.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridSupplies.ColumnHeadersHeight = 50;
            this.dataGridSupplies.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SupplyID,
            this.PrdID,
            this.Qntty,
            this.SuPID});
            this.dataGridSupplies.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridSupplies.Location = new System.Drawing.Point(0, 0);
            this.dataGridSupplies.Name = "dataGridSupplies";
            this.dataGridSupplies.RowHeadersVisible = false;
            this.dataGridSupplies.RowHeadersWidth = 60;
            this.dataGridSupplies.RowTemplate.Height = 24;
            this.dataGridSupplies.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridSupplies.Size = new System.Drawing.Size(1003, 530);
            this.dataGridSupplies.TabIndex = 0;
            // 
            // SupplyID
            // 
            this.SupplyID.HeaderText = "Supply ID";
            this.SupplyID.MinimumWidth = 6;
            this.SupplyID.Name = "SupplyID";
            // 
            // PrdID
            // 
            this.PrdID.HeaderText = "Product ID";
            this.PrdID.MinimumWidth = 6;
            this.PrdID.Name = "PrdID";
            // 
            // Qntty
            // 
            this.Qntty.HeaderText = "Quantity";
            this.Qntty.MinimumWidth = 6;
            this.Qntty.Name = "Qntty";
            // 
            // SuPID
            // 
            this.SuPID.HeaderText = "Supplier ID";
            this.SuPID.MinimumWidth = 6;
            this.SuPID.Name = "SuPID";
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.panel2.Controls.Add(this.dataGridSupplier);
            this.panel2.Location = new System.Drawing.Point(3, 41);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(995, 530);
            this.panel2.TabIndex = 1;
            // 
            // dataGridSupplier
            // 
            this.dataGridSupplier.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridSupplier.ColumnHeadersHeight = 50;
            this.dataGridSupplier.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SuPlyrID,
            this.CmpNm,
            this.Addrss,
            this.PhnNo});
            this.dataGridSupplier.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridSupplier.Location = new System.Drawing.Point(0, 0);
            this.dataGridSupplier.Name = "dataGridSupplier";
            this.dataGridSupplier.RowHeadersVisible = false;
            this.dataGridSupplier.RowHeadersWidth = 60;
            this.dataGridSupplier.RowTemplate.Height = 24;
            this.dataGridSupplier.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridSupplier.Size = new System.Drawing.Size(995, 530);
            this.dataGridSupplier.TabIndex = 0;
            // 
            // SuPlyrID
            // 
            this.SuPlyrID.HeaderText = "Supplier ID";
            this.SuPlyrID.MinimumWidth = 6;
            this.SuPlyrID.Name = "SuPlyrID";
            // 
            // CmpNm
            // 
            this.CmpNm.HeaderText = "Company Name";
            this.CmpNm.MinimumWidth = 6;
            this.CmpNm.Name = "CmpNm";
            // 
            // Addrss
            // 
            this.Addrss.HeaderText = "Address";
            this.Addrss.MinimumWidth = 6;
            this.Addrss.Name = "Addrss";
            // 
            // PhnNo
            // 
            this.PhnNo.HeaderText = "Phone No.";
            this.PhnNo.MinimumWidth = 6;
            this.PhnNo.Name = "PhnNo";
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel4.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.panel4.Controls.Add(this.panel6);
            this.panel4.Controls.Add(this.panel5);
            this.panel4.Controls.Add(this.btnEditSupplier);
            this.panel4.Controls.Add(this.btnDelete);
            this.panel4.Controls.Add(this.btnRefresh);
            this.panel4.Controls.Add(this.btnAddSupplier);
            this.panel4.Controls.Add(this.btnAddSupply);
            this.panel4.Controls.Add(this.srchSupplies);
            this.panel4.Location = new System.Drawing.Point(0, 31);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1224, 650);
            this.panel4.TabIndex = 2;
            // 
            // panel6
            // 
            this.panel6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel6.BackColor = System.Drawing.Color.Beige;
            this.panel6.Controls.Add(this.panel2);
            this.panel6.Controls.Add(this.lblSupplier);
            this.panel6.Location = new System.Drawing.Point(210, 68);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(1001, 574);
            this.panel6.TabIndex = 3;
            // 
            // lblSupplier
            // 
            this.lblSupplier.AutoSize = true;
            this.lblSupplier.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSupplier.Location = new System.Drawing.Point(25, 6);
            this.lblSupplier.Name = "lblSupplier";
            this.lblSupplier.Size = new System.Drawing.Size(161, 32);
            this.lblSupplier.TabIndex = 2;
            this.lblSupplier.Text = "SUPPLIER";
            // 
            // panel5
            // 
            this.panel5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.panel5.BackColor = System.Drawing.Color.Beige;
            this.panel5.Controls.Add(this.panel1);
            this.panel5.Controls.Add(this.lblSupply);
            this.panel5.Location = new System.Drawing.Point(12, 68);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1009, 574);
            this.panel5.TabIndex = 3;
            // 
            // lblSupply
            // 
            this.lblSupply.AutoSize = true;
            this.lblSupply.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSupply.Location = new System.Drawing.Point(23, 6);
            this.lblSupply.Name = "lblSupply";
            this.lblSupply.Size = new System.Drawing.Size(132, 32);
            this.lblSupply.TabIndex = 2;
            this.lblSupply.Text = "SUPPLY";
            // 
            // btnEditSupplier
            // 
            this.btnEditSupplier.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnEditSupplier.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditSupplier.Location = new System.Drawing.Point(795, 17);
            this.btnEditSupplier.Name = "btnEditSupplier";
            this.btnEditSupplier.Size = new System.Drawing.Size(226, 38);
            this.btnEditSupplier.TabIndex = 1;
            this.btnEditSupplier.Text = "EDIT SUPPLIER";
            this.btnEditSupplier.UseVisualStyleBackColor = true;
            this.btnEditSupplier.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.Location = new System.Drawing.Point(1034, 17);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(174, 38);
            this.btnDelete.TabIndex = 1;
            this.btnDelete.Text = "DELETE";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnRefresh
            // 
            this.btnRefresh.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRefresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefresh.Location = new System.Drawing.Point(612, 17);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(174, 38);
            this.btnRefresh.TabIndex = 1;
            this.btnRefresh.Text = "REFRESH";
            this.btnRefresh.UseVisualStyleBackColor = true;
            // 
            // btnAddSupplier
            // 
            this.btnAddSupplier.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAddSupplier.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddSupplier.Location = new System.Drawing.Point(93, 17);
            this.btnAddSupplier.Name = "btnAddSupplier";
            this.btnAddSupplier.Size = new System.Drawing.Size(259, 38);
            this.btnAddSupplier.TabIndex = 1;
            this.btnAddSupplier.Text = "ADD SUPPLIER";
            this.btnAddSupplier.UseVisualStyleBackColor = true;
            this.btnAddSupplier.Click += new System.EventHandler(this.btnAddSupplier_Click);
            // 
            // btnAddSupply
            // 
            this.btnAddSupply.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAddSupply.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddSupply.Location = new System.Drawing.Point(371, 17);
            this.btnAddSupply.Name = "btnAddSupply";
            this.btnAddSupply.Size = new System.Drawing.Size(226, 38);
            this.btnAddSupply.TabIndex = 1;
            this.btnAddSupply.Text = "ADD SUPPLY";
            this.btnAddSupply.UseVisualStyleBackColor = true;
            this.btnAddSupply.Click += new System.EventHandler(this.btnAddSupply_Click);
            // 
            // srchSupplies
            // 
            this.srchSupplies.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.srchSupplies.Location = new System.Drawing.Point(12, 17);
            this.srchSupplies.Name = "srchSupplies";
            this.srchSupplies.Size = new System.Drawing.Size(438, 38);
            this.srchSupplies.TabIndex = 0;
            this.srchSupplies.Text = "SEARCH";
            this.srchSupplies.MouseClick += new System.Windows.Forms.MouseEventHandler(this.srchProduct_MouseClick);
            this.srchSupplies.MouseLeave += new System.EventHandler(this.srchProduct_MouseLeave);
            // 
            // Supplies
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.ForestGreen;
            this.ClientSize = new System.Drawing.Size(1224, 685);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.panel4);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Supplies";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Supplies";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridSupplies)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridSupplier)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mENUToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eXITToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gOTOToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iNVENTORYToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pOSToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dataGridSupplies;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView dataGridSupplier;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label lblSupplier;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label lblSupply;
        private System.Windows.Forms.Button btnEditSupplier;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnAddSupply;
        private System.Windows.Forms.TextBox srchSupplies;
        private System.Windows.Forms.DataGridViewTextBoxColumn SuPlyrID;
        private System.Windows.Forms.DataGridViewTextBoxColumn CmpNm;
        private System.Windows.Forms.DataGridViewTextBoxColumn Addrss;
        private System.Windows.Forms.DataGridViewTextBoxColumn PhnNo;
        private System.Windows.Forms.Button btnAddSupplier;
        private System.Windows.Forms.DataGridViewTextBoxColumn SupplyID;
        private System.Windows.Forms.DataGridViewTextBoxColumn PrdID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Qntty;
        private System.Windows.Forms.DataGridViewTextBoxColumn SuPID;
        private System.Windows.Forms.ToolStripMenuItem eMPLOYEEToolStripMenuItem;
    }
}