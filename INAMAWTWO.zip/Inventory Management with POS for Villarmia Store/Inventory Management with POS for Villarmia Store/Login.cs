﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Inventory_Management_with_POS_for_Villarmia_Store
{
    private const string connectionString = "Data Source=LAPTOP-TV289K79\\SQLEXPRESS;Initial Catalog=villarmiaStore;Integrated Security=True";
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
            txtPass.PasswordChar = '*';
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsr.Text;
            string password = txtPass.Text;

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Please enter both username and password.");
                return;
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand("CheckLogin", connection);
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.AddWithValue("@Username", username);
                    command.Parameters.AddWithValue("@Password", password);

                    SqlParameter resultParameter = new SqlParameter("@Result", SqlDbType.Int);
                    resultParameter.Direction = ParameterDirection.Output;
                    command.Parameters.Add(resultParameter);

                    command.ExecuteNonQuery();

                    int loginResult = (int)resultParameter.Value;

                    if (loginResult == 1)
                    {
                        MessageBox.Show("Login successful!");
                        POS pOS = new POS();
                        pOS.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Login failed. Please check your username and password.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            Registration rgs = new Registration();
            rgs.Show();
            this.Hide();
        }
    }
}
