﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Inventory_Management_with_POS_for_Villarmia_Store
{
    public partial class EditInventory : Form
    {
        private const string connectionString = "Data Source=LAPTOP-TV289K79\\SQLEXPRESS;Initial Catalog=villarmiaStore;Integrated Security=True";
        public EditInventory()
        {
            InitializeComponent();
            LoadProductData();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are there no mistakes typed in the inputs?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                // Get user inputs from text boxes
                if (int.TryParse(txtStckNo.Text, out int stockNo))
                {
                    int productID = int.Parse(txtPrdID.Text); // You can use int.TryParse() for safety
                    int quantity = int.Parse(txtQntty.Text);
                    DateTime deliveryDate = dTimeDeliveryDate.Value; // Get the selected date from the DateTimePicker

                    // Call a method to update the inventory
                    UpdateInventory(stockNo, productID, quantity, deliveryDate);

                    // Optionally, refresh the data grid view or take any other actions as needed.
                    LoadProductData();
                }
                else
                {
                    MessageBox.Show("Invalid Stock No. Please enter a valid integer.");
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to Cancel?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                Inventory inv = new Inventory();
                inv.Show();
                this.Hide();
            }
        }

        private void txtQntty_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblQntty_Click(object sender, EventArgs e)
        {

        }

        private void UpdateInventory(int stockNo, int productID, int quantity, DateTime deliveryDate)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    using (SqlCommand cmd = new SqlCommand("UpdateInventory", connection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@stockNo", stockNo);
                        cmd.Parameters.AddWithValue("@productID", productID);
                        cmd.Parameters.AddWithValue("@quantity", quantity);
                        cmd.Parameters.AddWithValue("@deliveryDate", deliveryDate);

                        cmd.ExecuteNonQuery();

                        // Optionally, you can handle success or show a message to the user.
                        MessageBox.Show("Inventory updated successfully.");
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions, log errors, or show an error message to the user.
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private void LoadProductData()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM [dbo].[GetInventoryData]()", connection))
                {
                    cmd.CommandType = CommandType.Text;

                    try
                    {
                        connection.Open();
                        SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);
                        dataGridInventory.DataSource = dataTable;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An error occurred: " + ex.Message);
                    }
                }
            }
        }
    }
}
