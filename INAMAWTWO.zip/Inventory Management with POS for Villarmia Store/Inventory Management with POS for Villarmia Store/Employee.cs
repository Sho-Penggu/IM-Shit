﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory_Management_with_POS_for_Villarmia_Store
{
    public partial class Employee : Form
    {
        public Employee()
        {
            InitializeComponent();
        }

        private void btnEdt_Click(object sender, EventArgs e)
        {
            //Pop-up Confirm 1st
            Employee emp = new Employee();
            try
            {
                using (EditEmployee edtemp = new EditEmployee())
                {
                    emp.StartPosition = FormStartPosition.Manual;
                    emp.FormBorderStyle = FormBorderStyle.None;
                    emp.Opacity = 77.77;
                    emp.BackColor = Color.Black;
                    emp.WindowState = FormWindowState.Maximized;
                    emp.TopMost = true;
                    emp.Location = this.Location;
                    emp.ShowInTaskbar = false;
                    emp.Show();

                    edtemp.Owner = emp;
                    edtemp.ShowDialog();

                    emp.Dispose();
                    this.Hide();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                emp.Dispose();
            }
        }

        private void btnRem_Click(object sender, EventArgs e)
        {
            //Pop-up Remove 1st
            if (MessageBox.Show("Are you sure you want to REMOVE this Employee?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                if (MessageBox.Show("THE SAID EMPLOYEE WILL BE REMOVE PERMANENTLY IN THE DATABASE!", "WARNING MESSAGE!!!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    Employee emp = new Employee();
                    emp.Show();
                    this.Hide();
                }
            }
        }

        private void eXITToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pOSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            POS pos = new POS();
            pos.Show();
            this.Hide();
        }

        private void iNVENTORYToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Inventory inv = new Inventory();
            inv.Show();
            this.Hide();
        }
    }
}
