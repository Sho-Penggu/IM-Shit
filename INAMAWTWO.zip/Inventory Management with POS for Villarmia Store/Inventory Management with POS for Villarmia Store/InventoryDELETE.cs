﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory_Management_with_POS_for_Villarmia_Store
{
    private const string connectionString = "Data Source=LAPTOP-TV289K79\\SQLEXPRESS;Initial Catalog=villarmiaStore;Integrated Security=True";
    public partial class InventoryDELETE : Form
    {
        public InventoryDELETE()
        {
            InitializeComponent();
            LoadProductData();
        }

        private void txtSrch_MouseClick(object sender, MouseEventArgs e)
        {
            txtSrch.Clear();
        }

        private void txtSrch_MouseLeave(object sender, EventArgs e)
        {
            if (txtSrch.Text == "")
            {
                txtSrch.Text = "SEARCH";
            }
        }

        private bool CheckProductExistsInInventory(int productID)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT 1 FROM Inventory WHERE product_ID = @ProductID", connection))
                {
                    cmd.Parameters.Add("@ProductID", SqlDbType.Int).Value = productID;
                    return cmd.ExecuteScalar() != null;
                }
            }
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to DELETE this Item?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                // Retrieve the product ID from the user input (assuming the user inputs a valid product ID)
                if (int.TryParse(txtSrch.Text, out int productID))
                {
                    if (CheckProductExistsInInventory(productID))
                    {
                        // Product exists in the INVENTORY table, it cannot be deleted
                        MessageBox.Show("Product cannot be deleted because it exists in the Inventory.");
                    }
                    else
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            using (SqlCommand cmd = new SqlCommand("DELETE FROM Product WHERE product_ID = @ProductID", connection))
                            {
                                cmd.Parameters.Add("@ProductID", SqlDbType.Int).Value = productID;

                                try
                                {
                                    connection.Open();
                                    int rowsAffected = cmd.ExecuteNonQuery();
                                    if (rowsAffected > 0)
                                    {
                                        // Product deleted successfully
                                        MessageBox.Show("Product deleted successfully.");
                                    }
                                    else
                                    {
                                        // Product not found in the Product table
                                        MessageBox.Show("Product not found in the database.");
                                    }
                                }
                                catch (SqlException ex)
                                {
                                    MessageBox.Show("An error occurred: " + ex.Message);
                                }
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Invalid product ID. Please enter a valid product ID.");
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to Cancel?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                Inventory inv = new Inventory();
                inv.Show();
                this.Hide();
            }
        }

        private void LoadProductData()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM [dbo].[GetProductData]()", connection))
                {
                    cmd.CommandType = CommandType.Text;

                    try
                    {
                        connection.Open();
                        SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);
                        dataGridProduct.DataSource = dataTable;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An error occurred: " + ex.Message);
                    }
                }
            }
        }
    }
}
