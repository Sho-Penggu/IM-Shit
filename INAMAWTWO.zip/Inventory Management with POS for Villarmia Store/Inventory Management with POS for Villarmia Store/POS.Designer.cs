﻿namespace Inventory_Management_with_POS_for_Villarmia_Store
{
    partial class POS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(POS));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnRefrsh = new System.Windows.Forms.Button();
            this.btnSrch = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnEnterAmount = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.lblTotalNumber = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblPrice = new System.Windows.Forms.Label();
            this.lblChange = new System.Windows.Forms.Label();
            this.txtprice = new System.Windows.Forms.TextBox();
            this.lblPOS = new System.Windows.Forms.Label();
            this.lblProduct = new System.Windows.Forms.Label();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.GridPurchase = new System.Windows.Forms.DataGridView();
            this.BrCd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nme = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Qntty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SubTTl = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel2 = new System.Windows.Forms.Panel();
            this.GridProduct = new System.Windows.Forms.DataGridView();
            this.PrdID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PrdNm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Prc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CatgID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.srchQntty = new System.Windows.Forms.TextBox();
            this.srchPrd = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.mENUToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eXITToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vIEWSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iNVENTORYToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sUPPLIESToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GridPurchase)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GridProduct)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.panel1.Controls.Add(this.btnRefrsh);
            this.panel1.Controls.Add(this.btnSrch);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.lblPOS);
            this.panel1.Controls.Add(this.lblProduct);
            this.panel1.Controls.Add(this.btnConfirm);
            this.panel1.Controls.Add(this.btnRemove);
            this.panel1.Controls.Add(this.btnAdd);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.srchQntty);
            this.panel1.Controls.Add(this.srchPrd);
            this.panel1.Location = new System.Drawing.Point(0, 31);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1255, 644);
            this.panel1.TabIndex = 0;
            // 
            // btnRefrsh
            // 
            this.btnRefrsh.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnRefrsh.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefrsh.Location = new System.Drawing.Point(436, 37);
            this.btnRefrsh.Name = "btnRefrsh";
            this.btnRefrsh.Size = new System.Drawing.Size(169, 40);
            this.btnRefrsh.TabIndex = 3;
            this.btnRefrsh.TabStop = false;
            this.btnRefrsh.Text = "REFRESH";
            this.btnRefrsh.UseVisualStyleBackColor = true;
            this.btnRefrsh.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // btnSrch
            // 
            this.btnSrch.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnSrch.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSrch.Location = new System.Drawing.Point(236, 37);
            this.btnSrch.Name = "btnSrch";
            this.btnSrch.Size = new System.Drawing.Size(169, 40);
            this.btnSrch.TabIndex = 3;
            this.btnSrch.TabStop = false;
            this.btnSrch.Text = "SEARCH";
            this.btnSrch.UseVisualStyleBackColor = true;
            this.btnSrch.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panel4.BackColor = System.Drawing.Color.Honeydew;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel4.Controls.Add(this.btnEnterAmount);
            this.panel4.Controls.Add(this.panel5);
            this.panel4.Controls.Add(this.label2);
            this.panel4.Controls.Add(this.lblPrice);
            this.panel4.Controls.Add(this.lblChange);
            this.panel4.Controls.Add(this.txtprice);
            this.panel4.Location = new System.Drawing.Point(683, 3);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(569, 388);
            this.panel4.TabIndex = 5;
            // 
            // btnEnterAmount
            // 
            this.btnEnterAmount.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnEnterAmount.BackColor = System.Drawing.Color.DimGray;
            this.btnEnterAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEnterAmount.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnEnterAmount.Location = new System.Drawing.Point(467, 34);
            this.btnEnterAmount.Name = "btnEnterAmount";
            this.btnEnterAmount.Size = new System.Drawing.Size(95, 38);
            this.btnEnterAmount.TabIndex = 7;
            this.btnEnterAmount.Text = "ENTER";
            this.btnEnterAmount.UseVisualStyleBackColor = false;
            this.btnEnterAmount.Click += new System.EventHandler(this.btnEnterAmount_Click);
            // 
            // panel5
            // 
            this.panel5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel5.BackColor = System.Drawing.Color.Silver;
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel5.Controls.Add(this.lblTotalNumber);
            this.panel5.Controls.Add(this.lblTotal);
            this.panel5.Location = new System.Drawing.Point(3, 164);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(564, 68);
            this.panel5.TabIndex = 6;
            // 
            // lblTotalNumber
            // 
            this.lblTotalNumber.AutoSize = true;
            this.lblTotalNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalNumber.Location = new System.Drawing.Point(186, 11);
            this.lblTotalNumber.Name = "lblTotalNumber";
            this.lblTotalNumber.Size = new System.Drawing.Size(56, 46);
            this.lblTotalNumber.TabIndex = 5;
            this.lblTotalNumber.Text = "...";
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.Location = new System.Drawing.Point(3, 11);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(177, 46);
            this.lblTotal.TabIndex = 4;
            this.lblTotal.Text = "TOTAL :";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(165, 316);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 32);
            this.label2.TabIndex = 5;
            this.label2.Text = "...";
            // 
            // lblPrice
            // 
            this.lblPrice.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblPrice.AutoSize = true;
            this.lblPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrice.Location = new System.Drawing.Point(5, 37);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(113, 32);
            this.lblPrice.TabIndex = 4;
            this.lblPrice.Text = "CASH :";
            // 
            // lblChange
            // 
            this.lblChange.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblChange.AutoSize = true;
            this.lblChange.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChange.Location = new System.Drawing.Point(13, 316);
            this.lblChange.Name = "lblChange";
            this.lblChange.Size = new System.Drawing.Size(149, 32);
            this.lblChange.TabIndex = 4;
            this.lblChange.Text = "CHANGE :";
            // 
            // txtprice
            // 
            this.txtprice.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtprice.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtprice.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtprice.Location = new System.Drawing.Point(138, 34);
            this.txtprice.Name = "txtprice";
            this.txtprice.Size = new System.Drawing.Size(323, 38);
            this.txtprice.TabIndex = 0;
            this.txtprice.TextChanged += new System.EventHandler(this.txtprice_TextChanged);
            this.txtprice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtprice_KeyPress);
            // 
            // lblPOS
            // 
            this.lblPOS.AutoSize = true;
            this.lblPOS.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPOS.Location = new System.Drawing.Point(4, 183);
            this.lblPOS.Name = "lblPOS";
            this.lblPOS.Size = new System.Drawing.Size(238, 32);
            this.lblPOS.TabIndex = 4;
            this.lblPOS.Text = "POINT OF SALE";
            // 
            // lblProduct
            // 
            this.lblProduct.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblProduct.AutoSize = true;
            this.lblProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProduct.Location = new System.Drawing.Point(683, 401);
            this.lblProduct.Name = "lblProduct";
            this.lblProduct.Size = new System.Drawing.Size(159, 32);
            this.lblProduct.TabIndex = 4;
            this.lblProduct.Text = "PRODUCT";
            // 
            // btnConfirm
            // 
            this.btnConfirm.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConfirm.Location = new System.Drawing.Point(425, 140);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(169, 40);
            this.btnConfirm.TabIndex = 3;
            this.btnConfirm.TabStop = false;
            this.btnConfirm.Text = "CONFIRM";
            this.btnConfirm.UseVisualStyleBackColor = true;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemove.Location = new System.Drawing.Point(225, 140);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(169, 40);
            this.btnRemove.TabIndex = 3;
            this.btnRemove.Text = "REMOVE";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.Location = new System.Drawing.Point(21, 140);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(169, 40);
            this.btnAdd.TabIndex = 3;
            this.btnAdd.Text = "ADD";
            this.btnAdd.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.Controls.Add(this.GridPurchase);
            this.panel3.Location = new System.Drawing.Point(3, 218);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(674, 423);
            this.panel3.TabIndex = 2;
            // 
            // GridPurchase
            // 
            this.GridPurchase.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.GridPurchase.ColumnHeadersHeight = 50;
            this.GridPurchase.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.BrCd,
            this.Nme,
            this.Qntty,
            this.SubTTl});
            this.GridPurchase.Dock = System.Windows.Forms.DockStyle.Fill;
            this.GridPurchase.Location = new System.Drawing.Point(0, 0);
            this.GridPurchase.Name = "GridPurchase";
            this.GridPurchase.RowHeadersVisible = false;
            this.GridPurchase.RowHeadersWidth = 60;
            this.GridPurchase.RowTemplate.Height = 24;
            this.GridPurchase.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.GridPurchase.Size = new System.Drawing.Size(674, 423);
            this.GridPurchase.TabIndex = 0;
            // 
            // BrCd
            // 
            this.BrCd.HeaderText = "Barcode";
            this.BrCd.MinimumWidth = 6;
            this.BrCd.Name = "BrCd";
            // 
            // Nme
            // 
            this.Nme.HeaderText = "Name";
            this.Nme.MinimumWidth = 6;
            this.Nme.Name = "Nme";
            // 
            // Qntty
            // 
            this.Qntty.HeaderText = "Quantity";
            this.Qntty.MinimumWidth = 6;
            this.Qntty.Name = "Qntty";
            // 
            // SubTTl
            // 
            this.SubTTl.HeaderText = "Sub Total";
            this.SubTTl.MinimumWidth = 6;
            this.SubTTl.Name = "SubTTl";
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.Controls.Add(this.GridProduct);
            this.panel2.Location = new System.Drawing.Point(683, 436);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(569, 205);
            this.panel2.TabIndex = 1;
            // 
            // GridProduct
            // 
            this.GridProduct.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.GridProduct.ColumnHeadersHeight = 50;
            this.GridProduct.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.PrdID,
            this.PrdNm,
            this.Prc,
            this.CatgID});
            this.GridProduct.Dock = System.Windows.Forms.DockStyle.Fill;
            this.GridProduct.Location = new System.Drawing.Point(0, 0);
            this.GridProduct.Name = "GridProduct";
            this.GridProduct.RowHeadersVisible = false;
            this.GridProduct.RowHeadersWidth = 60;
            this.GridProduct.RowTemplate.Height = 24;
            this.GridProduct.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.GridProduct.Size = new System.Drawing.Size(569, 205);
            this.GridProduct.TabIndex = 0;
            // 
            // PrdID
            // 
            this.PrdID.HeaderText = "Product ID";
            this.PrdID.MinimumWidth = 6;
            this.PrdID.Name = "PrdID";
            // 
            // PrdNm
            // 
            this.PrdNm.HeaderText = "Product Name";
            this.PrdNm.MinimumWidth = 6;
            this.PrdNm.Name = "PrdNm";
            // 
            // Prc
            // 
            this.Prc.HeaderText = "Price";
            this.Prc.MinimumWidth = 6;
            this.Prc.Name = "Prc";
            // 
            // CatgID
            // 
            this.CatgID.HeaderText = "Category ID";
            this.CatgID.MinimumWidth = 6;
            this.CatgID.Name = "CatgID";
            // 
            // srchQntty
            // 
            this.srchQntty.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.srchQntty.Location = new System.Drawing.Point(35, 96);
            this.srchQntty.Name = "srchQntty";
            this.srchQntty.Size = new System.Drawing.Size(256, 38);
            this.srchQntty.TabIndex = 0;
            this.srchQntty.Text = "QUANTITY";
            this.srchQntty.MouseClick += new System.Windows.Forms.MouseEventHandler(this.txtQntty_MouseClick);
            this.srchQntty.MouseLeave += new System.EventHandler(this.txtQntty_MouseLeave);
            // 
            // srchPrd
            // 
            this.srchPrd.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.srchPrd.Location = new System.Drawing.Point(35, 39);
            this.srchPrd.Name = "srchPrd";
            this.srchPrd.Size = new System.Drawing.Size(512, 38);
            this.srchPrd.TabIndex = 0;
            this.srchPrd.Text = "SEARCH";
            this.srchPrd.MouseClick += new System.Windows.Forms.MouseEventHandler(this.srch_MouseClick);
            this.srchPrd.MouseLeave += new System.EventHandler(this.srch_MouseLeave);
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Aquamarine;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mENUToolStripMenuItem,
            this.vIEWSToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1255, 30);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // mENUToolStripMenuItem
            // 
            this.mENUToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.eXITToolStripMenuItem});
            this.mENUToolStripMenuItem.Name = "mENUToolStripMenuItem";
            this.mENUToolStripMenuItem.Size = new System.Drawing.Size(65, 26);
            this.mENUToolStripMenuItem.Text = "MENU";
            // 
            // eXITToolStripMenuItem
            // 
            this.eXITToolStripMenuItem.Name = "eXITToolStripMenuItem";
            this.eXITToolStripMenuItem.Size = new System.Drawing.Size(121, 26);
            this.eXITToolStripMenuItem.Text = "EXIT";
            this.eXITToolStripMenuItem.Click += new System.EventHandler(this.eXITToolStripMenuItem_Click);
            // 
            // vIEWSToolStripMenuItem
            // 
            this.vIEWSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.iNVENTORYToolStripMenuItem,
            this.sUPPLIESToolStripMenuItem});
            this.vIEWSToolStripMenuItem.Name = "vIEWSToolStripMenuItem";
            this.vIEWSToolStripMenuItem.Size = new System.Drawing.Size(66, 26);
            this.vIEWSToolStripMenuItem.Text = "GO TO";
            // 
            // iNVENTORYToolStripMenuItem
            // 
            this.iNVENTORYToolStripMenuItem.Name = "iNVENTORYToolStripMenuItem";
            this.iNVENTORYToolStripMenuItem.Size = new System.Drawing.Size(170, 26);
            this.iNVENTORYToolStripMenuItem.Text = "INVENTORY";
            this.iNVENTORYToolStripMenuItem.Click += new System.EventHandler(this.iNVENTORYToolStripMenuItem_Click);
            // 
            // sUPPLIESToolStripMenuItem
            // 
            this.sUPPLIESToolStripMenuItem.Name = "sUPPLIESToolStripMenuItem";
            this.sUPPLIESToolStripMenuItem.Size = new System.Drawing.Size(170, 26);
            this.sUPPLIESToolStripMenuItem.Text = "SUPPLIES";
            this.sUPPLIESToolStripMenuItem.Click += new System.EventHandler(this.sUPPLIESToolStripMenuItem_Click);
            // 
            // POS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.ForestGreen;
            this.ClientSize = new System.Drawing.Size(1255, 687);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "POS";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "POS";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.GridPurchase)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.GridProduct)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox srchPrd;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView GridProduct;
        private System.Windows.Forms.Button btnConfirm;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.DataGridView GridPurchase;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Label lblProduct;
        private System.Windows.Forms.Label lblTotalNumber;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mENUToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eXITToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vIEWSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iNVENTORYToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sUPPLIESToolStripMenuItem;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.TextBox txtprice;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblChange;
        private System.Windows.Forms.Button btnEnterAmount;
        private System.Windows.Forms.Label lblPOS;
        private System.Windows.Forms.DataGridViewTextBoxColumn BrCd;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nme;
        private System.Windows.Forms.DataGridViewTextBoxColumn Qntty;
        private System.Windows.Forms.DataGridViewTextBoxColumn SubTTl;
        private System.Windows.Forms.Button btnRefrsh;
        private System.Windows.Forms.Button btnSrch;
        private System.Windows.Forms.DataGridViewTextBoxColumn PrdID;
        private System.Windows.Forms.DataGridViewTextBoxColumn PrdNm;
        private System.Windows.Forms.DataGridViewTextBoxColumn Prc;
        private System.Windows.Forms.DataGridViewTextBoxColumn CatgID;
        private System.Windows.Forms.TextBox srchQntty;
    }
}