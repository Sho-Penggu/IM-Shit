﻿namespace Inventory_Management_with_POS_for_Villarmia_Store
{
    partial class InventoryDELETE
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(InventoryDELETE));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.txtSrch = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dataGridProduct = new System.Windows.Forms.DataGridView();
            this.PrdID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PrdNm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Qntty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CatgID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StckNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RefID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DelDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblTITLE = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridProduct)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.lblTITLE);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1039, 617);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Honeydew;
            this.panel2.Controls.Add(this.btnConfirm);
            this.panel2.Controls.Add(this.btnCancel);
            this.panel2.Controls.Add(this.txtSrch);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Location = new System.Drawing.Point(15, 54);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1012, 549);
            this.panel2.TabIndex = 1;
            // 
            // btnConfirm
            // 
            this.btnConfirm.BackColor = System.Drawing.Color.LightGreen;
            this.btnConfirm.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConfirm.Location = new System.Drawing.Point(735, 481);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(196, 51);
            this.btnConfirm.TabIndex = 2;
            this.btnConfirm.Text = "CONFIRM";
            this.btnConfirm.UseVisualStyleBackColor = false;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.IndianRed;
            this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.Location = new System.Drawing.Point(85, 481);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(196, 51);
            this.btnCancel.TabIndex = 2;
            this.btnCancel.Text = "CANCEL";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // txtSrch
            // 
            this.txtSrch.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtSrch.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSrch.Location = new System.Drawing.Point(41, 40);
            this.txtSrch.Name = "txtSrch";
            this.txtSrch.Size = new System.Drawing.Size(576, 45);
            this.txtSrch.TabIndex = 1;
            this.txtSrch.Text = "SEARCH";
            this.txtSrch.MouseClick += new System.Windows.Forms.MouseEventHandler(this.txtSrch_MouseClick);
            this.txtSrch.MouseLeave += new System.EventHandler(this.txtSrch_MouseLeave);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.dataGridProduct);
            this.panel3.Location = new System.Drawing.Point(9, 132);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(992, 327);
            this.panel3.TabIndex = 0;
            // 
            // dataGridProduct
            // 
            this.dataGridProduct.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridProduct.ColumnHeadersHeight = 50;
            this.dataGridProduct.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.PrdID,
            this.PrdNm,
            this.Qntty,
            this.CatgID,
            this.StckNo,
            this.RefID,
            this.DelDate});
            this.dataGridProduct.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridProduct.Location = new System.Drawing.Point(0, 0);
            this.dataGridProduct.Name = "dataGridProduct";
            this.dataGridProduct.RowHeadersVisible = false;
            this.dataGridProduct.RowHeadersWidth = 60;
            this.dataGridProduct.RowTemplate.Height = 24;
            this.dataGridProduct.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridProduct.Size = new System.Drawing.Size(992, 327);
            this.dataGridProduct.TabIndex = 0;
            // 
            // PrdID
            // 
            this.PrdID.HeaderText = "Product ID";
            this.PrdID.MinimumWidth = 6;
            this.PrdID.Name = "PrdID";
            // 
            // PrdNm
            // 
            this.PrdNm.HeaderText = "Product Name";
            this.PrdNm.MinimumWidth = 6;
            this.PrdNm.Name = "PrdNm";
            // 
            // Qntty
            // 
            this.Qntty.HeaderText = "Quantity";
            this.Qntty.MinimumWidth = 6;
            this.Qntty.Name = "Qntty";
            // 
            // CatgID
            // 
            this.CatgID.HeaderText = "Category ID";
            this.CatgID.MinimumWidth = 6;
            this.CatgID.Name = "CatgID";
            // 
            // StckNo
            // 
            this.StckNo.HeaderText = "Stock No.";
            this.StckNo.MinimumWidth = 6;
            this.StckNo.Name = "StckNo";
            // 
            // RefID
            // 
            this.RefID.HeaderText = "Referential ID";
            this.RefID.MinimumWidth = 6;
            this.RefID.Name = "RefID";
            // 
            // DelDate
            // 
            this.DelDate.HeaderText = "Delivery Date";
            this.DelDate.MinimumWidth = 6;
            this.DelDate.Name = "DelDate";
            // 
            // lblTITLE
            // 
            this.lblTITLE.AutoSize = true;
            this.lblTITLE.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTITLE.Location = new System.Drawing.Point(346, 9);
            this.lblTITLE.Name = "lblTITLE";
            this.lblTITLE.Size = new System.Drawing.Size(373, 42);
            this.lblTITLE.TabIndex = 0;
            this.lblTITLE.Text = "DELETE PRODUCT";
            // 
            // InventoryDELETE
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.ForestGreen;
            this.ClientSize = new System.Drawing.Size(1063, 641);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "InventoryDELETE";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "InventoryDELETE";
            this.TopMost = true;
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridProduct)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DataGridView dataGridProduct;
        private System.Windows.Forms.Label lblTITLE;
        private System.Windows.Forms.Button btnConfirm;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.TextBox txtSrch;
        private System.Windows.Forms.DataGridViewTextBoxColumn PrdID;
        private System.Windows.Forms.DataGridViewTextBoxColumn PrdNm;
        private System.Windows.Forms.DataGridViewTextBoxColumn Qntty;
        private System.Windows.Forms.DataGridViewTextBoxColumn CatgID;
        private System.Windows.Forms.DataGridViewTextBoxColumn StckNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn RefID;
        private System.Windows.Forms.DataGridViewTextBoxColumn DelDate;
    }
}