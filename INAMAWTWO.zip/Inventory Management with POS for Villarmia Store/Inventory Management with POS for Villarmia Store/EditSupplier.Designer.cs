﻿namespace Inventory_Management_with_POS_for_Villarmia_Store
{
    partial class EditSupplier
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EditSupplier));
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblTitle = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.txtPhnNum = new System.Windows.Forms.TextBox();
            this.txtAddrss = new System.Windows.Forms.TextBox();
            this.txtCompaNm = new System.Windows.Forms.TextBox();
            this.txtSuplyrID = new System.Windows.Forms.TextBox();
            this.lblPhnNo = new System.Windows.Forms.Label();
            this.lblAddrss = new System.Windows.Forms.Label();
            this.lblCompNm = new System.Windows.Forms.Label();
            this.lblSupyr = new System.Windows.Forms.Label();
            this.lblSuplrID = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dataGridSupplier = new System.Windows.Forms.DataGridView();
            this.SuplyrID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CompNm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Addrss = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PhnNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridSupplier)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.panel1.Controls.Add(this.lblTitle);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(6, 6);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1484, 810);
            this.panel1.TabIndex = 0;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(676, 20);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(309, 42);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "EDIT SUPPLIER";
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackColor = System.Drawing.Color.Honeydew;
            this.panel2.Controls.Add(this.btnSave);
            this.panel2.Controls.Add(this.btnCancel);
            this.panel2.Controls.Add(this.txtPhnNum);
            this.panel2.Controls.Add(this.txtAddrss);
            this.panel2.Controls.Add(this.txtCompaNm);
            this.panel2.Controls.Add(this.txtSuplyrID);
            this.panel2.Controls.Add(this.lblPhnNo);
            this.panel2.Controls.Add(this.lblAddrss);
            this.panel2.Controls.Add(this.lblCompNm);
            this.panel2.Controls.Add(this.lblSupyr);
            this.panel2.Controls.Add(this.lblSuplrID);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Location = new System.Drawing.Point(19, 79);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1441, 716);
            this.panel2.TabIndex = 0;
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnSave.BackColor = System.Drawing.Color.LightGreen;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(489, 631);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(196, 51);
            this.btnSave.TabIndex = 3;
            this.btnSave.Text = "SAVE";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnCancel.BackColor = System.Drawing.Color.IndianRed;
            this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.Location = new System.Drawing.Point(57, 631);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(196, 51);
            this.btnCancel.TabIndex = 3;
            this.btnCancel.Text = "CANCEL";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // txtPhnNum
            // 
            this.txtPhnNum.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtPhnNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPhnNum.Location = new System.Drawing.Point(276, 528);
            this.txtPhnNum.Name = "txtPhnNum";
            this.txtPhnNum.Size = new System.Drawing.Size(432, 38);
            this.txtPhnNum.TabIndex = 2;
            // 
            // txtAddrss
            // 
            this.txtAddrss.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtAddrss.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddrss.Location = new System.Drawing.Point(276, 395);
            this.txtAddrss.Name = "txtAddrss";
            this.txtAddrss.Size = new System.Drawing.Size(432, 38);
            this.txtAddrss.TabIndex = 2;
            // 
            // txtCompaNm
            // 
            this.txtCompaNm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtCompaNm.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCompaNm.Location = new System.Drawing.Point(276, 245);
            this.txtCompaNm.Name = "txtCompaNm";
            this.txtCompaNm.Size = new System.Drawing.Size(432, 38);
            this.txtCompaNm.TabIndex = 2;
            // 
            // txtSuplyrID
            // 
            this.txtSuplyrID.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtSuplyrID.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSuplyrID.Location = new System.Drawing.Point(276, 85);
            this.txtSuplyrID.Name = "txtSuplyrID";
            this.txtSuplyrID.Size = new System.Drawing.Size(432, 38);
            this.txtSuplyrID.TabIndex = 2;
            // 
            // lblPhnNo
            // 
            this.lblPhnNo.AutoSize = true;
            this.lblPhnNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhnNo.Location = new System.Drawing.Point(71, 528);
            this.lblPhnNo.Name = "lblPhnNo";
            this.lblPhnNo.Size = new System.Drawing.Size(174, 32);
            this.lblPhnNo.TabIndex = 1;
            this.lblPhnNo.Text = "Phone No. :";
            // 
            // lblAddrss
            // 
            this.lblAddrss.AutoSize = true;
            this.lblAddrss.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddrss.Location = new System.Drawing.Point(103, 398);
            this.lblAddrss.Name = "lblAddrss";
            this.lblAddrss.Size = new System.Drawing.Size(142, 32);
            this.lblAddrss.TabIndex = 1;
            this.lblAddrss.Text = "Address :";
            // 
            // lblCompNm
            // 
            this.lblCompNm.AutoSize = true;
            this.lblCompNm.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCompNm.Location = new System.Drawing.Point(7, 245);
            this.lblCompNm.Name = "lblCompNm";
            this.lblCompNm.Size = new System.Drawing.Size(246, 32);
            this.lblCompNm.TabIndex = 1;
            this.lblCompNm.Text = "Company Name :";
            // 
            // lblSupyr
            // 
            this.lblSupyr.AutoSize = true;
            this.lblSupyr.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSupyr.Location = new System.Drawing.Point(776, 14);
            this.lblSupyr.Name = "lblSupyr";
            this.lblSupyr.Size = new System.Drawing.Size(161, 32);
            this.lblSupyr.TabIndex = 1;
            this.lblSupyr.Text = "SUPPLIER";
            // 
            // lblSuplrID
            // 
            this.lblSuplrID.AutoSize = true;
            this.lblSuplrID.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSuplrID.Location = new System.Drawing.Point(63, 85);
            this.lblSuplrID.Name = "lblSuplrID";
            this.lblSuplrID.Size = new System.Drawing.Size(182, 32);
            this.lblSuplrID.TabIndex = 1;
            this.lblSuplrID.Text = "Supplier ID :";
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.Controls.Add(this.dataGridSupplier);
            this.panel3.Location = new System.Drawing.Point(766, 49);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(658, 655);
            this.panel3.TabIndex = 0;
            // 
            // dataGridSupplier
            // 
            this.dataGridSupplier.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridSupplier.ColumnHeadersHeight = 50;
            this.dataGridSupplier.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SuplyrID,
            this.CompNm,
            this.Addrss,
            this.PhnNo});
            this.dataGridSupplier.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridSupplier.Location = new System.Drawing.Point(0, 0);
            this.dataGridSupplier.Name = "dataGridSupplier";
            this.dataGridSupplier.RowHeadersVisible = false;
            this.dataGridSupplier.RowHeadersWidth = 60;
            this.dataGridSupplier.RowTemplate.Height = 24;
            this.dataGridSupplier.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridSupplier.Size = new System.Drawing.Size(658, 655);
            this.dataGridSupplier.TabIndex = 0;
            // 
            // SuplyrID
            // 
            this.SuplyrID.HeaderText = "Supplier ID";
            this.SuplyrID.MinimumWidth = 6;
            this.SuplyrID.Name = "SuplyrID";
            // 
            // CompNm
            // 
            this.CompNm.HeaderText = "Company Name";
            this.CompNm.MinimumWidth = 6;
            this.CompNm.Name = "CompNm";
            // 
            // Addrss
            // 
            this.Addrss.HeaderText = "Address";
            this.Addrss.MinimumWidth = 6;
            this.Addrss.Name = "Addrss";
            // 
            // PhnNo
            // 
            this.PhnNo.HeaderText = "Phone No.";
            this.PhnNo.MinimumWidth = 6;
            this.PhnNo.Name = "PhnNo";
            // 
            // EditSupplier
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.ForestGreen;
            this.ClientSize = new System.Drawing.Size(1495, 829);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "EditSupplier";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "EditSupplies";
            this.TopMost = true;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridSupplier)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblSuplrID;
        private System.Windows.Forms.DataGridView dataGridSupplier;
        private System.Windows.Forms.Label lblAddrss;
        private System.Windows.Forms.Label lblCompNm;
        private System.Windows.Forms.TextBox txtAddrss;
        private System.Windows.Forms.TextBox txtCompaNm;
        private System.Windows.Forms.TextBox txtSuplyrID;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label lblSupyr;
        private System.Windows.Forms.TextBox txtPhnNum;
        private System.Windows.Forms.Label lblPhnNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn SuplyrID;
        private System.Windows.Forms.DataGridViewTextBoxColumn CompNm;
        private System.Windows.Forms.DataGridViewTextBoxColumn Addrss;
        private System.Windows.Forms.DataGridViewTextBoxColumn PhnNo;
    }
}