﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory_Management_with_POS_for_Villarmia_Store
{
    private const string connectionString = "Data Source=LAPTOP-TV289K79\\SQLEXPRESS;Initial Catalog=villarmiaStore;Integrated Security=True";

    public partial class ADDinventory : Form
    {
        public ADDinventory()
        {
            InitializeComponent();
            LoadProductData();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            // Get user input from textboxes and combobox
            string productName = txtPrdName.Text;
            int price;
            int categoryID;

            if (string.IsNullOrWhiteSpace(productName) || !int.TryParse(txtPrc.Text, out price) || ComboCatg.SelectedItem == null)
            {
                MessageBox.Show("Please ensure all fields are filled correctly.");
                return;
            }

            switch (ComboCatg.SelectedItem.ToString())
            {
                case "KITCHEN":
                    categoryID = 100;
                    break;
                case "BATHROOM":
                    categoryID = 101;
                    break;
                case "PLASTICWARES":
                    categoryID = 102;
                    break;
                case "LAUNDRY":
                    categoryID = 103;
                    break;
                case "MISCELLANEOUS":
                    categoryID = 104;
                    break;
                default:
                    categoryID = 105;
                    break;
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("InsertProduct", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@ProductName", SqlDbType.NVarChar, 255).Value = productName;
                    cmd.Parameters.Add("@Price", SqlDbType.Int).Value = price;
                    cmd.Parameters.Add("@CategoryID", SqlDbType.Int).Value = categoryID;

                    try
                    {
                        connection.Open();
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Product added successfully!");
                        Inventory inv = new Inventory();
                        inv.Show();
                        this.Hide();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An error occurred: " + ex.Message);
                    }
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to Cancel?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Inventory inv = new Inventory();
                inv.Show();
                this.Hide();
            }
        }

        private void LoadProductData()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM [dbo].[GetProductData]()", connection))
                {
                    cmd.CommandType = CommandType.Text;

                    try
                    {
                        connection.Open();
                        SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);
                        dataGridProduct.DataSource = dataTable;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An error occurred: " + ex.Message);
                    }
                }
            }
        }

    }
}
