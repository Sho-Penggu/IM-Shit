﻿namespace Inventory_Management_with_POS_for_Villarmia_Store
{
    partial class EditInventory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EditInventory));
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblTitle = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dataGridInventory = new System.Windows.Forms.DataGridView();
            this.StckNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PrdID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PrdNm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Qntty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CatgID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RefID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DelDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtQntty = new System.Windows.Forms.TextBox();
            this.txtPrdID = new System.Windows.Forms.TextBox();
            this.txtStckNo = new System.Windows.Forms.TextBox();
            this.lblDelDate = new System.Windows.Forms.Label();
            this.lblStckNo = new System.Windows.Forms.Label();
            this.lblQntty = new System.Windows.Forms.Label();
            this.lblInv = new System.Windows.Forms.Label();
            this.lblPrdID = new System.Windows.Forms.Label();
            this.dTimeDeliveryDate = new System.Windows.Forms.DateTimePicker();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridInventory)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.panel1.Controls.Add(this.lblTitle);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(6, 6);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1616, 922);
            this.panel1.TabIndex = 0;
            // 
            // lblTitle
            // 
            this.lblTitle.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(647, 15);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(343, 42);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "EDIT INVENTORY";
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackColor = System.Drawing.Color.Honeydew;
            this.panel2.Controls.Add(this.dTimeDeliveryDate);
            this.panel2.Controls.Add(this.btnSave);
            this.panel2.Controls.Add(this.btnCancel);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.txtQntty);
            this.panel2.Controls.Add(this.txtPrdID);
            this.panel2.Controls.Add(this.txtStckNo);
            this.panel2.Controls.Add(this.lblDelDate);
            this.panel2.Controls.Add(this.lblStckNo);
            this.panel2.Controls.Add(this.lblQntty);
            this.panel2.Controls.Add(this.lblInv);
            this.panel2.Controls.Add(this.lblPrdID);
            this.panel2.Location = new System.Drawing.Point(19, 79);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1576, 822);
            this.panel2.TabIndex = 0;
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnSave.BackColor = System.Drawing.Color.LightGreen;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(485, 734);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(196, 51);
            this.btnSave.TabIndex = 4;
            this.btnSave.Text = "SAVE";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnCancel.BackColor = System.Drawing.Color.IndianRed;
            this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.Location = new System.Drawing.Point(53, 734);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(196, 51);
            this.btnCancel.TabIndex = 4;
            this.btnCancel.Text = "CANCEL";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.Controls.Add(this.dataGridInventory);
            this.panel3.Location = new System.Drawing.Point(766, 49);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(793, 761);
            this.panel3.TabIndex = 3;
            // 
            // dataGridInventory
            // 
            this.dataGridInventory.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridInventory.ColumnHeadersHeight = 50;
            this.dataGridInventory.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.StckNo,
            this.PrdID,
            this.PrdNm,
            this.Qntty,
            this.CatgID,
            this.RefID,
            this.DelDate});
            this.dataGridInventory.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridInventory.Location = new System.Drawing.Point(0, 0);
            this.dataGridInventory.Name = "dataGridInventory";
            this.dataGridInventory.RowHeadersVisible = false;
            this.dataGridInventory.RowHeadersWidth = 60;
            this.dataGridInventory.RowTemplate.Height = 24;
            this.dataGridInventory.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridInventory.Size = new System.Drawing.Size(793, 761);
            this.dataGridInventory.TabIndex = 0;
            // 
            // StckNo
            // 
            this.StckNo.HeaderText = "Stock No.";
            this.StckNo.MinimumWidth = 6;
            this.StckNo.Name = "StckNo";
            // 
            // PrdID
            // 
            this.PrdID.HeaderText = "Product ID";
            this.PrdID.MinimumWidth = 6;
            this.PrdID.Name = "PrdID";
            // 
            // PrdNm
            // 
            this.PrdNm.HeaderText = "Product Name";
            this.PrdNm.MinimumWidth = 6;
            this.PrdNm.Name = "PrdNm";
            // 
            // Qntty
            // 
            this.Qntty.HeaderText = "Quantity";
            this.Qntty.MinimumWidth = 6;
            this.Qntty.Name = "Qntty";
            // 
            // CatgID
            // 
            this.CatgID.HeaderText = "Category ID";
            this.CatgID.MinimumWidth = 6;
            this.CatgID.Name = "CatgID";
            // 
            // RefID
            // 
            this.RefID.HeaderText = "Referential ID";
            this.RefID.MinimumWidth = 6;
            this.RefID.Name = "RefID";
            // 
            // DelDate
            // 
            this.DelDate.HeaderText = "Delivery Date";
            this.DelDate.MinimumWidth = 6;
            this.DelDate.Name = "DelDate";
            // 
            // txtQntty
            // 
            this.txtQntty.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtQntty.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQntty.Location = new System.Drawing.Point(268, 444);
            this.txtQntty.Name = "txtQntty";
            this.txtQntty.Size = new System.Drawing.Size(478, 38);
            this.txtQntty.TabIndex = 1;
            this.txtQntty.TextChanged += new System.EventHandler(this.txtQntty_TextChanged);
            // 
            // txtPrdID
            // 
            this.txtPrdID.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtPrdID.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPrdID.Location = new System.Drawing.Point(268, 255);
            this.txtPrdID.Name = "txtPrdID";
            this.txtPrdID.Size = new System.Drawing.Size(478, 38);
            this.txtPrdID.TabIndex = 1;
            // 
            // txtStckNo
            // 
            this.txtStckNo.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtStckNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStckNo.Location = new System.Drawing.Point(271, 46);
            this.txtStckNo.Name = "txtStckNo";
            this.txtStckNo.Size = new System.Drawing.Size(478, 38);
            this.txtStckNo.TabIndex = 1;
            // 
            // lblDelDate
            // 
            this.lblDelDate.AutoSize = true;
            this.lblDelDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDelDate.Location = new System.Drawing.Point(28, 627);
            this.lblDelDate.Name = "lblDelDate";
            this.lblDelDate.Size = new System.Drawing.Size(214, 32);
            this.lblDelDate.TabIndex = 0;
            this.lblDelDate.Text = "Delivery Date :";
            // 
            // lblStckNo
            // 
            this.lblStckNo.AutoSize = true;
            this.lblStckNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStckNo.Location = new System.Drawing.Point(80, 49);
            this.lblStckNo.Name = "lblStckNo";
            this.lblStckNo.Size = new System.Drawing.Size(162, 32);
            this.lblStckNo.TabIndex = 0;
            this.lblStckNo.Text = "Stock No. :";
            // 
            // lblQntty
            // 
            this.lblQntty.AutoSize = true;
            this.lblQntty.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQntty.Location = new System.Drawing.Point(96, 450);
            this.lblQntty.Name = "lblQntty";
            this.lblQntty.Size = new System.Drawing.Size(146, 32);
            this.lblQntty.TabIndex = 0;
            this.lblQntty.Text = "Quantity :";
            this.lblQntty.Click += new System.EventHandler(this.lblQntty_Click);
            // 
            // lblInv
            // 
            this.lblInv.AutoSize = true;
            this.lblInv.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInv.Location = new System.Drawing.Point(774, 14);
            this.lblInv.Name = "lblInv";
            this.lblInv.Size = new System.Drawing.Size(186, 32);
            this.lblInv.TabIndex = 0;
            this.lblInv.Text = "INVENTORY";
            // 
            // lblPrdID
            // 
            this.lblPrdID.AutoSize = true;
            this.lblPrdID.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrdID.Location = new System.Drawing.Point(69, 258);
            this.lblPrdID.Name = "lblPrdID";
            this.lblPrdID.Size = new System.Drawing.Size(173, 32);
            this.lblPrdID.TabIndex = 0;
            this.lblPrdID.Text = "Product ID :";
            // 
            // dTimeDeliveryDate
            // 
            this.dTimeDeliveryDate.CalendarTitleBackColor = System.Drawing.SystemColors.ControlText;
            this.dTimeDeliveryDate.CalendarTitleForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.dTimeDeliveryDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dTimeDeliveryDate.Location = new System.Drawing.Point(268, 627);
            this.dTimeDeliveryDate.Name = "dTimeDeliveryDate";
            this.dTimeDeliveryDate.Size = new System.Drawing.Size(478, 38);
            this.dTimeDeliveryDate.TabIndex = 5;
            // 
            // EditInventory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.ForestGreen;
            this.ClientSize = new System.Drawing.Size(1630, 935);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "EditInventory";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "EditInventory";
            this.TopMost = true;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridInventory)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblPrdID;
        private System.Windows.Forms.Label lblQntty;
        private System.Windows.Forms.TextBox txtStckNo;
        private System.Windows.Forms.TextBox txtPrdID;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DataGridView dataGridInventory;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label lblInv;
        private System.Windows.Forms.TextBox txtQntty;
        private System.Windows.Forms.Label lblDelDate;
        private System.Windows.Forms.Label lblStckNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn StckNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn PrdID;
        private System.Windows.Forms.DataGridViewTextBoxColumn PrdNm;
        private System.Windows.Forms.DataGridViewTextBoxColumn Qntty;
        private System.Windows.Forms.DataGridViewTextBoxColumn CatgID;
        private System.Windows.Forms.DataGridViewTextBoxColumn RefID;
        private System.Windows.Forms.DataGridViewTextBoxColumn DelDate;
        private System.Windows.Forms.DateTimePicker dTimeDeliveryDate;
    }
}